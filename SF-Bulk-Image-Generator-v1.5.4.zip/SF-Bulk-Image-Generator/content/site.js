// Skillful Freelance website: when the student is signed in on skillfulfreelance.com in this browser, connect this
// installation to that account by itself (same browser = same person). Nothing is sent anywhere else.
(async () => {
  try {
    const st = await chrome.storage.local.get(['deviceId', 'deviceSecret', 'autoLinkedTo']);
    if (!st.deviceId || !st.deviceSecret) return;                // open the extension once first
    const r = await fetch('/auth/extension-link', {
      method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ product: 'bulk-image', deviceId: st.deviceId, secret: st.deviceSecret })
    });
    if (!r.ok) return;                                           // not signed in, or nothing to do
    const j = await r.json();
    if (!j.linked || j.already || st.autoLinkedTo === j.email) return;
    await chrome.storage.local.set({ autoLinkedTo: j.email });
    const box = document.createElement('div');
    box.textContent = '✅ Bulk Image Generator এই ব্রাউজারে আপনার অ্যাকাউন্টে (' + j.email + ') যুক্ত হলো — নাম, WhatsApp আর লাইসেন্স এখন এক জায়গায়।';
    box.style.cssText = 'position:fixed;left:50%;bottom:24px;transform:translateX(-50%);z-index:2147483646;max-width:92vw;padding:12px 18px;border-radius:12px;background:#16a34a;color:#fff;font:600 14px/1.5 system-ui,sans-serif;box-shadow:0 8px 30px rgba(0,0,0,.25)';
    document.documentElement.appendChild(box);
    setTimeout(() => box.remove(), 9000);
  } catch { /* the website keeps working normally */ }
})();
