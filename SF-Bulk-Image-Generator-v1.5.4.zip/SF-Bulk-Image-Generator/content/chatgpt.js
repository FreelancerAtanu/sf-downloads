// Skillful Freelance — Bulk Image Generator : ChatGPT page driver.
// It only acts on messages from the extension dashboard; it never runs on its own.
(() => {
  // After the extension is reloaded, the copy already in the page is dead (its chrome.runtime is gone).
  // Only skip when a LIVE copy is present; otherwise install this fresh one.
  try { if (window.__sfBulkDriver && window.__sfBulkDriver.alive()) return; } catch { /* dead copy */ }
  window.__sfBulkDriver = { alive: () => { try { return !!chrome.runtime.id; } catch { return false; } } };

  // Selector lists are tried in order. The licence server can push replacements (admin "hot-fix").
  const SEL = {
    // ChatGPT has two prompt boxes in use: the older rich editor and a newer plain text box (name="prompt")
    composer: ['#prompt-textarea', 'div.ProseMirror[contenteditable="true"]', 'textarea[data-testid="prompt-textarea"]', 'textarea[name="prompt"]', '#mobile-composer-prompt', 'textarea[aria-label*="ChatGPT" i]', 'main form textarea', 'form textarea', '[contenteditable="true"][role="textbox"]'],
    send: ['button[data-testid="send-button"]', 'button[data-testid="composer-send-button"]', '#composer-submit-button', 'button[aria-label="Send prompt"]', 'button[aria-label="Send message"]', 'button[aria-label*="Send" i]', 'form button[type="submit"]'],
    stop: ['button[data-testid="stop-button"]', 'button[aria-label="Stop streaming"]', 'button[aria-label*="Stop" i]'],
    assistant: ['[data-message-author-role="assistant"]'],
    user: ['[data-message-author-role="user"]'],
    turn: ['article[data-testid^="conversation-turn"]', '[data-testid^="conversation-turn"]', 'article'],
    newChat: ['a[data-testid="create-new-chat-button"]', 'button[data-testid="create-new-chat-button"]', 'a[aria-label="New chat"]', 'button[aria-label="New chat"]'],
    login: ['button[data-testid="login-button"]', 'a[href*="/auth/login"]'],
    imageUrl: 'oaiusercontent\\.com|/backend-api/|estuary|files\\.openai',
    busyText: 'creating image|generating image|getting started|adding details|almost (done|there)|finishing up|image is being created|working on (it|your)|starting',
    limitText: "(reached|hit|exceeded) (the|your|our)[^.]{0,60}limit|too many requests|rate limit|image generation limit|try again (later|in \\d)|limit resets|you've reached",
    toolFailText: "did ?n.t accept the request|image generation (failed|failure|error)|could ?n.t generate (the |an |that |your )?image|unable to generate (the |an |that |your )?image|(error|problem|issue|trouble) (while |when )?(generating|creating)|something went wrong",
    refuseText: "content polic|can(no|')t (create|generate|help|assist|produce)|violat|not able to (create|generate)|won't be able to (create|generate)"
  };

  function applyOverrides(o) {
    if (!o || typeof o !== 'object') return;
    for (const k of Object.keys(SEL)) {
      if (Array.isArray(SEL[k]) && Array.isArray(o[k]) && o[k].length) SEL[k] = o[k].filter(x => typeof x === 'string').concat(SEL[k]);
      else if (typeof SEL[k] === 'string' && typeof o[k] === 'string' && o[k]) SEL[k] = o[k];
    }
  }

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  function q(list, root) {
    for (const s of list) {
      try { const el = (root || document).querySelector(s); if (el) return el; } catch { /* bad selector */ }
    }
    return null;
  }
  function qa(list, root) {
    for (const s of list) {
      try { const els = (root || document).querySelectorAll(s); if (els.length) return [...els]; } catch { /* bad selector */ }
    }
    return [];
  }
  const visible = el => !!el && el.getClientRects().length > 0;

  function stopButton() {
    for (const s of SEL.stop) {
      let el; try { el = document.querySelector(s); } catch { continue; }
      if (el && visible(el)) return el;
    }
    return null;
  }
  function sendButton() {
    for (const s of SEL.send) {
      let els; try { els = document.querySelectorAll(s); } catch { continue; }
      for (const el of els) {
        const label = ((el.getAttribute('aria-label') || '') + ' ' + (el.getAttribute('data-testid') || '')).toLowerCase();
        if (label.includes('stop') || label.includes('voice') || label.includes('dictat')) continue;
        if (visible(el)) return el;
      }
    }
    return null;
  }

  function imageKey(src) {
    try {
      const u = new URL(src, location.href);
      return u.searchParams.get('id') || u.pathname;
    } catch { return src; }
  }

  // Generated images only: inside the conversation, not in a user message, big enough to not be an avatar/icon.
  function collectImages() {
    const re = new RegExp(SEL.imageUrl, 'i');
    const userSel = SEL.user.join(',');
    const out = new Map();
    const scope = document.querySelector('main') || document.body;
    for (const img of scope.querySelectorAll('img')) {
      const src = img.currentSrc || img.src || '';
      if (!src || src.startsWith('data:')) continue;
      let inUser = false;
      try { inUser = !!img.closest(userSel); } catch { /* ignore */ }
      if (inUser) continue;
      const looksGenerated = re.test(src) || /generated image/i.test(img.alt || '');
      if (!looksGenerated) continue;
      if (img.complete && img.naturalWidth > 0 && img.naturalWidth < 300) continue;
      const key = imageKey(src);
      const prev = out.get(key);
      const rec = { key, src, w: img.naturalWidth, h: img.naturalHeight, complete: img.complete && img.naturalWidth > 0 };
      if (!prev || (rec.complete && !prev.complete)) out.set(key, rec);
    }
    return [...out.values()];
  }

  function lastAssistantText() {
    const turns = qa(SEL.assistant);
    const last = turns[turns.length - 1];
    if (!last) return '';
    const host = last.closest(SEL.turn.join(',')) || last;
    return (host.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 500);
  }

  function status() {
    const text = lastAssistantText();
    const pageText = text || '';
    const test = (pattern) => { try { return new RegExp(pattern, 'i').test(pageText); } catch { return false; } };
    return {
      ok: true,
      url: location.href,
      ready: !!q(SEL.composer),
      hidden: document.visibilityState !== 'visible',
      hidden: document.visibilityState !== 'visible',
      loggedOut: !q(SEL.composer) && !!q(SEL.login),
      streaming: !!stopButton(),
      assistantCount: qa(SEL.assistant).length,
      userCount: qa(SEL.user).length,
      images: collectImages(),
      lastText: text,
      busyHint: test(SEL.busyText),
      limitHint: test(SEL.limitText),
      toolFailHint: test(SEL.toolFailText),
      refuseHint: test(SEL.refuseText)
    };
  }

  function composerText(el) {
    return (el.tagName === 'TEXTAREA' ? el.value : el.innerText || '').trim();
  }

  async function setComposer(el, text) {
    el.focus();
    if (el.tagName === 'TEXTAREA') {
      const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set;
      setter.call(el, text);
      el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return;
    }
    // Rich editor: clear, then type with insertText — the editor treats it like real typing, so ChatGPT
    // registers the text and enables Send. Paste is only the fallback.
    const sel = window.getSelection();
    sel.selectAllChildren(el);
    if (composerText(el)) document.execCommand('delete');
    try { document.execCommand('insertText', false, text); } catch { /* fall through */ }
    await sleep(150);
    if (composerText(el)) return;
    sel.selectAllChildren(el);
    try {
      const dt = new DataTransfer();
      dt.setData('text/plain', text);
      el.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
    } catch { /* fall through */ }
    await sleep(120);
    if (!composerText(el)) {
      el.focus();
      document.execCommand('insertText', false, text);
      await sleep(120);
    }
  }
  /** Clear the box and type the text again — used once when Send stays disabled. */
  async function retype(el, text) {
    el.focus();
    const sel = window.getSelection();
    sel.selectAllChildren(el);
    try { document.execCommand('delete'); } catch { /* ignore */ }
    await sleep(150);
    try { el.dispatchEvent(new InputEvent('beforeinput', { bubbles: true, cancelable: true, inputType: 'insertText', data: text })); } catch { /* ignore */ }
    try { document.execCommand('insertText', false, text); } catch { /* ignore */ }
    await sleep(300);
  }

  async function sendPrompt(text) {
    const el = q(SEL.composer);
    if (!el) return { ok: false, error: 'ChatGPT prompt box not found. Is the page loaded and are you logged in?' };
    if (stopButton()) return { ok: false, error: 'ChatGPT is still answering the previous message.' };
    const before = qa(SEL.user).length;
    await setComposer(el, text);
    await sleep(350 + Math.random() * 500);
    if (!composerText(el)) return { ok: false, error: 'Could not type the prompt into ChatGPT.' };

    const left = () => qa(SEL.user).length > before || !!stopButton() || (() => { const c = q(SEL.composer); return !!c && !composerText(c); })();
    const settle = async (ms) => { for (let t = 0; t < ms; t += 250) { await sleep(250); if (qa(SEL.user).length > before || stopButton()) return true; } const c = q(SEL.composer); return !!c && !composerText(c); };
    const enabledButton = async (ms) => {
      for (let t = 0; t < ms; t += 200) {
        const b = sendButton();
        if (b && !b.disabled && b.getAttribute('aria-disabled') !== 'true') return b;
        await sleep(200);
      }
      return null;
    };
    // 1) the Send button (waits until ChatGPT has registered the text)
    let btn = await enabledButton(8000);
    if (!btn) {                               // Send still disabled: type the prompt again once, then wait again
      const c = q(SEL.composer) || el;
      if (c.tagName === 'TEXTAREA') c.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: ' ' }));
      else await retype(c, text);
      btn = await enabledButton(5000);
    }
    if (btn) { btn.click(); if (await settle(4000)) return { ok: true, via: 'button' }; }
    // 2) submit the form the box sits in
    const form = (q(SEL.composer) || el).closest('form');
    if (form && !left()) { try { form.requestSubmit(); } catch { /* not allowed */ } if (await settle(4000)) return { ok: true, via: 'form' }; }
    // 3) press the button once more, then Enter
    if (!left()) { const b2 = sendButton(); if (b2 && !b2.disabled) { b2.click(); if (await settle(4000)) return { ok: true, via: 'button2' }; } }
    if (!left()) {
      const c = q(SEL.composer) || el; c.focus();
      const ev = { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true, composed: true };
      c.dispatchEvent(new KeyboardEvent('keydown', ev)); c.dispatchEvent(new KeyboardEvent('keypress', ev)); c.dispatchEvent(new KeyboardEvent('keyup', ev));
      if (await settle(5000)) return { ok: true, via: 'enter' };
    }
    // separate reports for "no Send button at all" and "button there but disabled" — the admin panel counts them apart
    const why = btn ? 'The prompt was typed but ChatGPT did not send it.' : sendButton() ? 'The Send button stayed disabled after typing the prompt.' : 'The Send button was not found on the ChatGPT page.';
    return { ok: false, stage: btn ? 'not-sent' : 'send-disabled', hidden: document.visibilityState !== 'visible', error: why };
  }

  function baseChatUrl() {
    const m = location.pathname.match(/^\/g\/([^/]+)/);
    if (m) return location.origin + '/g/' + m[1] + (m[1].startsWith('g-p-') ? '/project' : '');
    return location.origin + '/';
  }

  async function newChat() {
    const inProject = /^\/g\//.test(location.pathname);
    if (!inProject) {
      const btn = q(SEL.newChat);
      if (btn && visible(btn)) {
        btn.click();
        for (let i = 0; i < 30; i++) {
          await sleep(250);
          if (!qa(SEL.assistant).length && q(SEL.composer)) return { ok: true, reloaded: false };
        }
      }
    }
    const target = baseChatUrl();
    setTimeout(() => { location.assign(target); }, 50);
    return { ok: true, reloaded: true };
  }

  async function fetchImage(src) {
    try {
      const r = await fetch(src, { credentials: 'include' });
      if (!r.ok) return { ok: false, error: 'HTTP ' + r.status };
      const blob = await r.blob();
      const dataUrl = await new Promise((res, rej) => {
        const fr = new FileReader();
        fr.onload = () => res(fr.result);
        fr.onerror = () => rej(fr.error);
        fr.readAsDataURL(blob);
      });
      return { ok: true, dataUrl, type: blob.type };
    } catch (e) {
      return { ok: false, error: String(e && e.message || e) };
    }
  }

  // Small status pill so the user can see progress while working in ChatGPT.
  let pill = null;
  function overlay(text, state) {
    if (!text) { if (pill) pill.remove(); pill = null; return; }
    if (!pill || !pill.isConnected) {
      pill = document.createElement('div');
      pill.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:2147483646;display:flex;align-items:center;gap:8px;padding:8px 12px;border-radius:999px;font:600 12px/1.2 system-ui,sans-serif;color:#fff;background:linear-gradient(135deg,#6d5efc,#22d3ee);box-shadow:0 6px 24px rgba(0,0,0,.35);cursor:pointer;max-width:340px';
      pill.title = 'Open Bulk Image Generator';
      pill.addEventListener('click', () => chrome.runtime.sendMessage({ type: 'sf-open-dashboard' }));
      const dot = document.createElement('span');
      dot.style.cssText = 'width:8px;height:8px;border-radius:50%;background:#fff;flex:none';
      const label = document.createElement('span');
      label.style.cssText = 'white-space:nowrap;overflow:hidden;text-overflow:ellipsis';
      pill.append(dot, label);
      document.documentElement.appendChild(pill);
    }
    pill.lastChild.textContent = text;
    pill.firstChild.style.opacity = state === 'paused' ? '.4' : '1';
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg || msg.target !== 'sf-driver') return;
    (async () => {
      try {
        switch (msg.cmd) {
          case 'ping': applyOverrides(msg.selectors); sendResponse(status()); break;
          case 'status': sendResponse(status()); break;
          case 'lastText': {
            // Everything ChatGPT wrote after the newest user message (an answer can be several blocks).
            const users = qa(SEL.user);
            const lastUser = users[users.length - 1];
            const all = qa(SEL.assistant);
            const els = lastUser ? all.filter((el) => lastUser.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING) : all.slice(-1);
            const code = [];
            let imgs = 0;
            for (const el of els) {
              el.querySelectorAll('pre').forEach((p) => { const c = p.querySelector('code') || p; code.push(c.innerText || c.textContent || ''); });
              imgs += el.querySelectorAll('img').length;
            }
            // answers written into a side "canvas" panel are outside the message
            let canvas = '';
            try { canvas = [...document.querySelectorAll('[data-testid*="canvas" i] .ProseMirror, [data-testid*="canvas" i] .cm-content, section[aria-label*="canvas" i] .ProseMirror')].map((el) => el.innerText || '').join('\n').slice(0, 300000); } catch { /* none */ }
            sendResponse({
              ok: true, count: all.length, userCount: users.length, streaming: !!stopButton(), images: imgs, canvas,
              text: els.map((el) => el.innerText || '').join('\n').slice(0, 300000),
              code: code.join('\n').slice(0, 300000)
            });
            break;
          }
          case 'send': sendResponse(await sendPrompt(String(msg.text || ''))); break;
          case 'newChat': sendResponse(await newChat()); break;
          case 'fetchImage': sendResponse(await fetchImage(msg.src)); break;
          case 'overlay': overlay(msg.text, msg.state); sendResponse({ ok: true }); break;
          default: sendResponse({ ok: false, error: 'Unknown command' });
        }
      } catch (e) {
        sendResponse({ ok: false, error: String(e && e.message || e) });
      }
    })();
    return true;
  });
})();
