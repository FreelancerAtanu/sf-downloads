// Service worker: opens (or focuses) the dashboard window when the toolbar icon is clicked.
const DASH = 'dashboard/dashboard.html';

async function openDashboard() {
  const url = chrome.runtime.getURL(DASH);
  const { dashWin } = await chrome.storage.session.get('dashWin');
  if (dashWin) {
    try {
      const w = await chrome.windows.get(dashWin, { populate: true });
      if (w && w.tabs && w.tabs.some(t => (t.url || t.pendingUrl || '').startsWith(url))) {
        await chrome.windows.update(dashWin, { focused: true, drawAttention: true });
        return;
      }
    } catch { /* window is gone */ }
  }
  const w = await chrome.windows.create({ url, type: 'popup', width: 540, height: 860 });
  await chrome.storage.session.set({ dashWin: w.id });
}

chrome.action.onClicked.addListener(openDashboard);

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.type === 'sf-open-dashboard') {
    openDashboard().then(() => sendResponse({ ok: true }));
    return true;
  }
});
