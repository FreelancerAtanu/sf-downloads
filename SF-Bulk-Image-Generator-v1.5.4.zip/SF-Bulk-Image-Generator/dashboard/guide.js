// Pop-ups for the dashboard: offer announcement, Bengali first-run tour, "How to use" video, image preview.
const $ = (s) => document.querySelector(s);
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

export function fmtLeft(ms) {
  if (ms <= 0) return 'শেষ';
  const d = Math.floor(ms / 864e5), h = Math.floor((ms % 864e5) / 36e5), m = Math.floor((ms % 36e5) / 6e4), s = Math.floor((ms % 6e4) / 1000);
  return (d ? d + 'd ' : '') + (d || h ? h + 'h ' : '') + m + 'm ' + String(s).padStart(2, '0') + 's';
}
// Every element with data-ends="<timestamp>" becomes a live countdown.
setInterval(() => {
  document.querySelectorAll('[data-ends]').forEach((el) => { el.textContent = fmtLeft(Number(el.dataset.ends) - Date.now()); });
}, 1000);

export function durText(hours) {
  if (hours % 24 === 0) { const d = hours / 24; return d + (d === 1 ? ' day' : ' days'); }
  if (Number.isInteger(hours)) return hours + (hours === 1 ? ' hour' : ' hours');
  return Math.round(hours * 60) + ' minutes';
}
export const offerActive = (p) => !!(p && p.offerPrice > 0 && p.offerEndsAt > Date.now());
export const effectivePrice = (p) => (offerActive(p) ? p.offerPrice : p.price);

// ───────────── generic modal ─────────────
export function closeModal() {
  $('#modal').classList.add('hide');
  $('#mbox').innerHTML = '';
  $('#mbox').className = 'mbox';
}
export function openModal(html, cls) {
  const box = $('#mbox');
  box.className = 'mbox ' + (cls || '');
  box.innerHTML = '<button class="mclose" id="mClose" title="Close">✕</button>' + html;
  $('#modal').classList.remove('hide');
  $('#mClose').onclick = closeModal;
  return box;
}
$('#modal').addEventListener('click', (e) => { if (e.target.id === 'modal') closeModal(); });

// ───────────── offer / announcement pop-up ─────────────
export function maybeShowOffer(cfg, onAccept, force) {
  if (!cfg) return false;
  const offers = (cfg.packages || []).filter(offerActive);
  const ann = cfg.announcement || '';
  if (!offers.length && !ann) return false;
  if (!$('#modal').classList.contains('hide') || document.querySelector('.tour')) return false;
  const key = ann + '|' + offers.map((p) => p.id + ':' + p.offerPrice + ':' + p.offerEndsAt).join(',');
  let seen = {};
  try { seen = JSON.parse(localStorage.getItem('sfOfferSeen') || '{}'); } catch { /* ignore */ }
  if (!force && seen.key === key && Date.now() - seen.t < 6 * 3600e3) return false;
  try { localStorage.setItem('sfOfferSeen', JSON.stringify({ key, t: Date.now() })); } catch { /* ignore */ }

  const cur = cfg.currency || '';
  const cards = offers.map((p) => `
    <div class="ocard">
      <div><b>${esc(p.name)}</b><span>${esc(durText(p.hours))}</span></div>
      <div class="oprice">${p.price ? `<s>${esc(cur)}${p.price}</s>` : ''}<strong>${esc(cur)}${p.offerPrice}</strong></div>
      <div class="otime">অফার শেষ হতে বাকি <b data-ends="${p.offerEndsAt}">${fmtLeft(p.offerEndsAt - Date.now())}</b></div>
      <button class="btn primary" data-offer="${esc(p.id)}">এই অফার নিন</button>
    </div>`).join('');
  const box = openModal(`
    <div class="obadge">${offers.length ? '🎁 SPECIAL OFFER' : '📢 NOTICE'}</div>
    ${ann ? `<p class="oann">${esc(ann)}</p>` : ''}
    ${cards}
    <button class="btn link" id="offerLater">পরে দেখব</button>`, 'offer');
  box.querySelector('#offerLater').onclick = closeModal;
  box.querySelectorAll('[data-offer]').forEach((b) => { b.onclick = () => { closeModal(); onAccept(b.dataset.offer); }; });
  return true;
}

// ───────────── image preview + Adobe check details ─────────────
export function openPreview(item) {
  const r = item.report;
  const checks = r ? `
    <div class="pscore ${r.score >= 80 ? 'g' : r.score >= 60 ? 'y' : 'r'}"><b>${r.score}</b><span>/100 · Adobe Stock check · ${esc(r.verdict)}</span></div>
    <ul class="pchecks">${r.checks.map((c) => `<li class="${c.ok ? 'ok' : 'no'}"><b>${c.ok ? '✓' : '✗'} ${esc(c.label)}</b> ${esc(c.detail)}</li>`).join('')}</ul>
    ${(r.manual || []).length ? `<p class="hint" style="margin-top:10px"><b>নিজে দেখে নিন (১০০% জুম করে):</b></p><ul class="pchecks">${r.manual.map((m) => `<li>☐ ${esc(m)}</li>`).join('')}</ul>` : ''}
    <p class="hint">টেকনিক্যাল নম্বরটা Adobe Stock-এর নিয়ম ধরে হিসাব করা (রেজোলিউশন, ফরম্যাট, সাইজ, শার্পনেস, নয়েজ, ব্যান্ডিং, JPEG ব্লক)। ৮০-র উপরে হলে টেকনিক্যাল দিক ঠিক আছে। উপরের তালিকার জিনিসগুলো কোনো সফটওয়্যার নিশ্চিত করতে পারে না — নিজে দেখে নিন। চূড়ান্ত সিদ্ধান্ত Adobe Stock-এর।</p>` : '';
  openModal(`
    <h3>#${item.number} ${esc(item.file || '')}</h3>
    ${item.preview ? `<img class="pimg" src="${item.preview}" alt="">` : '<p class="hint">এই ইমেজের প্রিভিউ এখন মেমরিতে নেই (ড্যাশবোর্ড বন্ধ করে খুললে প্রিভিউ মুছে যায়)। সেভ করা ফাইলটা ফোল্ডারে আছে।</p>'}
    <p class="pprompt">${esc(item.prompt)}</p>
    ${checks}`, 'preview');
}

// ───────────── How to use (video + tour) ─────────────
export function openHowTo(cfg, startTourFn, playerUrl) {
  const id = cfg && cfg.videoId;
  const box = openModal(`
    <h3>কীভাবে ব্যবহার করবেন</h3>
    ${id ? `<div class="vwrap" id="vwrap"><iframe src="${esc(playerUrl(id))}" title="How to use" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen"></iframe></div>
      <div class="row"><button class="btn ghost" id="vSize">⤢ বড় / ছোট করুন</button>
      <a class="btn ghost" href="https://www.youtube.com/watch?v=${esc(id)}" target="_blank" rel="noopener">ভিডিও না চললে YouTube-এ খুলুন</a></div>`
      : '<p class="hint">ভিডিও এখনও যোগ করা হয়নি। নিচের বাটনে ধাপে ধাপে গাইড দেখুন।</p>'}
    <div class="row"><button class="btn primary grow" id="tourGo">ধাপে ধাপে গাইড দেখুন</button></div>`, 'howto');
  const vs = box.querySelector('#vSize');
  if (vs) vs.onclick = () => box.classList.toggle('big');
  box.querySelector('#tourGo').onclick = () => { closeModal(); startTourFn(); };
}

// ───────────── first-run tour (Bengali) ─────────────
const STEPS = [
  { tab: 'generate', sel: '#promptBox', title: '১ · প্রম্পট দিন', text: 'আপনার সব প্রম্পট একসাথে এখানে পেস্ট করুন। একটা একটা করে দিতে হবে না।' },
  { tab: 'generate', sel: '#sepSelect', title: '২ · প্রম্পট কীভাবে আলাদা করা', text: 'প্রতি লাইনে একটা প্রম্পট হলে "Each line" রাখুন। প্রম্পট কয়েক লাইনের হলে মাঝে ফাঁকা লাইন দিন, অথবা নিজের সেপারেটর (যেমন ---) ব্যবহার করুন। উপরে ডান দিকে কয়টা প্রম্পট পাওয়া গেল তা দেখাবে।' },
  { tab: 'generate', sel: '#loadBtn', title: '৩ · কিউতে লোড করুন', text: 'এই বাটনে চাপলে প্রম্পটগুলো গুনে নিচের কিউতে চলে যাবে। পাশের বাটন দিয়ে .txt ফাইল থেকেও প্রম্পট আনা যায়।' },
  { tab: 'generate', sel: '.quick', title: '৪ · ইমেজের ধরন', text: 'Type = ফটো, ইলাস্ট্রেশন না আইকন। Shape = ইমেজের আকার। Upscale = সেভ করার আগে ইমেজ বড় করা। Adobe Stock-এর জন্য Upscale 2× রাখুন, কারণ Adobe কমপক্ষে 4 MP চায়।' },
  { tab: 'generate', sel: '#startBtn', title: '৫ · Start', text: 'ChatGPT-তে লগইন করা একটা ট্যাব খোলা রেখে Start চাপুন। এরপর সিস্টেম নিজে একটা একটা করে প্রম্পট পাঠাবে, ইমেজ ডাউনলোড করবে, আর ব্যাকগ্রাউন্ডে আপস্কেল করবে। Pause ও Stop দিয়ে থামানো যায়।' },
  { tab: 'generate', sel: '#queue', title: '৬ · কিউ ও ফলাফল', text: 'প্রতিটা প্রম্পটের অবস্থা এখানে দেখাবে। "Adobe 85" মানে Adobe Stock টেকনিক্যাল চেকে ১০০-র মধ্যে ৮৫। সারিতে ক্লিক করলে ইমেজ আর কোন কোন জায়গায় নম্বর কাটা গেছে তা দেখা যাবে।' },
  { tab: 'settings', sel: '#v-settings', title: '৭ · Settings', text: 'ফাইলের নাম, JPEG/PNG ফরম্যাট, কোন ফোল্ডারে সেভ হবে, আপস্কেলের মডেল, আর দুই প্রম্পটের মাঝে কত সেকেন্ড অপেক্ষা করবে — সব এখানে। শুরুতে ডিফল্ট সেটিংসই যথেষ্ট।' },
  { tab: 'adobe', sel: '#primeBtn', title: '৮ · Adobe Stock নিয়ম', text: '"Send rules to ChatGPT" চাপলে Adobe Stock-এর পুরো নিয়ম খোলা চ্যাটে চলে যায়। স্থায়ীভাবে চাইলে উপরের Project instructions ব্যবহার করুন।' },
  { tab: 'activity', sel: '#v-activity', title: '৯ · Activity', text: 'কী কী কাজ হয়েছে, কোনটা সেভ হলো, কোনটা ফেল করল ও কেন — সব এখানে লেখা থাকে। Clear log দিয়ে মুছে ফেলা যায়।' },
  { tab: null, sel: '#licChip', title: '১০ · লাইসেন্স', text: 'আপনার প্যাকেজ আর কত সময় বাকি তা এখানে দেখায়। ক্লিক করলে Device ID, প্যাকেজ ও রিনিউ করার অপশন পাবেন।' },
  { tab: null, sel: '#howBtn', title: 'শেষ!', text: 'এই গাইড বা ভিডিও আবার দেখতে চাইলে যেকোনো সময় "How to use" বাটনে চাপুন।' }
];

export function startTour(showTab, onDone) {
  closeModal();
  document.querySelectorAll('.tour').forEach((e) => e.remove());
  const wrap = document.createElement('div');
  wrap.className = 'tour';
  wrap.innerHTML = '<div class="thole"></div><div class="tcard"><b class="tt"></b><p class="tx"></p><div class="row"><span class="tn"></span><span class="grow"></span><button class="btn link" data-t="skip">বাদ দিন</button><button class="btn ghost" data-t="back">আগের</button><button class="btn primary" data-t="next">পরের ধাপ</button></div></div>';
  document.body.appendChild(wrap);
  const hole = wrap.querySelector('.thole'), card = wrap.querySelector('.tcard');
  let i = 0;
  function finish() { wrap.remove(); showTab('generate'); onDone && onDone(); }
  function place() {
    const st = STEPS[i];
    if (st.tab) showTab(st.tab);
    const el = $(st.sel);
    if (el) el.scrollIntoView({ block: 'center' });
    requestAnimationFrame(() => {
      const r = el ? el.getBoundingClientRect() : { left: 20, top: 80, width: 200, height: 40 };
      const vh = window.innerHeight, vw = window.innerWidth;
      const top = Math.max(4, r.top - 6), h = Math.min(r.height + 12, vh - top - 8);
      hole.style.cssText = `left:${Math.max(4, r.left - 6)}px;top:${top}px;width:${Math.min(r.width + 12, vw - 8)}px;height:${h}px`;
      wrap.querySelector('.tt').textContent = st.title;
      wrap.querySelector('.tx').textContent = st.text;
      wrap.querySelector('.tn').textContent = (i + 1) + ' / ' + STEPS.length;
      wrap.querySelector('[data-t=back]').disabled = i === 0;
      wrap.querySelector('[data-t=next]').textContent = i === STEPS.length - 1 ? 'বুঝেছি, শুরু করি' : 'পরের ধাপ';
      const ch = card.offsetHeight;
      const below = top + h + 10;
      card.style.top = (below + ch < vh - 8 ? below : Math.max(8, top - ch - 10)) + 'px';
      if (below + ch >= vh - 8 && top - ch - 10 < 8) card.style.top = (vh - ch - 12) + 'px';
    });
  }
  wrap.addEventListener('click', (e) => {
    const t = e.target.dataset && e.target.dataset.t;
    if (t === 'skip') finish();
    else if (t === 'back' && i > 0) { i--; place(); }
    else if (t === 'next') { if (i === STEPS.length - 1) finish(); else { i++; place(); } }
  });
  place();
}
