// Skillful Freelance — Bulk Image Generator : dashboard + job runner.
import { CONFIG } from '../config.js';
import { SEPARATORS, ASPECTS, MODES, parsePrompts, buildMessage, findNearDuplicates, buildFileName, PRIME_MESSAGE, promptMakerMessage, parseMadePrompts } from '../lib/prompts.js';
// the updater is loaded only when needed, so a half-finished update can never stop the dashboard from opening
import { getDevice, checkLicence, requestActivation, startLink, moveHere, addStat, addError, serverConfig, whatsappLink, qrUrl, playerUrl, backendLabel } from '../lib/backend.js';
import { blobToCanvas, canvasToBlob, dHash, hamming, analyzeQuality, vectorize, resample, hasAlpha } from '../lib/imaging.js';
import * as guide from './guide.js';
import { upscaleCanvas, benchmark } from '../lib/upscaler.js';

const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];

// ───────────────────────── settings ─────────────────────────
const DEFAULTS = {
  separator: 'line', customSep: '---', stripNumbers: true,
  mode: 'photo', aspect: '3:2', engine: 'full', antiSimilar: false, prefix: '', suffix: '',
  nameTemplate: '{prompt}_{n}', namePrefix: 'skillful', startNumber: 1, pad: 3,
  format: 'jpg', quality: 98, subfolder: 'SF-Bulk-Images', transparent: true, theme: '',
  upscale: true, upScale: '2', upModel: 'best', upStrength: 100, keepOriginal: false,
  qualityCheck: true, svg: true,
  dlMin: 3, dlMax: 6, nextMin: 5, nextMax: 12,
  breakEvery: 200, breakMinutes: 10, newChatEvery: 10, genTimeout: 300,
  retries: 2, retryDelay: 20, limitMinutes: 20, autoRetryFailed: true, stayInChat: false
};
let S = Object.assign({}, DEFAULTS);
let queue = [];          // { id, prompt, status, attempts, error, file, report, similar }
let logs = [];
let licence = { state: 'unknown', active: false, expiresAt: 0, plan: '' };
let srvConfig = null;
let device = null;
let dirHandle = null;
let chosenPack = '';

// ───────────────────────── small utilities ─────────────────────────
function toast(msg) {
  const t = $('#toast'); t.textContent = msg; t.classList.add('show');
  clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('show'), 2800);
}
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function log(msg, level) {
  logs.unshift({ t: Date.now(), msg, level: level || '' });
  if (logs.length > 600) logs.length = 600;
  renderLog();
  persistSoon();
}
function renderLog() {
  if ($('#v-activity').classList.contains('hide')) return;
  $('#log').innerHTML = logs.length
    ? logs.slice(0, 300).map((l) => `<div class="${l.level}"><span class="t">${new Date(l.t).toLocaleTimeString()}</span> ${esc(l.msg)}</div>`).join('')
    : '<div class="t">Nothing yet.</div>';
}

let persistTimer = null;
function persistSoon() {
  if (persistTimer) return;
  persistTimer = setTimeout(() => {
    persistTimer = null;
    chrome.storage.local.set({
      queue: queue.map((i) => ({ id: i.id, prompt: i.prompt, number: i.number, status: i.status, attempts: i.attempts, error: i.error, file: i.file, report: i.report, similar: i.similar })),
      logs: logs.slice(0, 300)
    });
  }, 500);
}

// Accurate sleeping (worker timers are not slowed down when this window is hidden).
const timerWorker = new Worker(new URL('../lib/timer-worker.js', import.meta.url));
const timerWaits = new Map();
let timerSeq = 0;
timerWorker.onmessage = (e) => { const r = timerWaits.get(e.data); if (r) { timerWaits.delete(e.data); r(); } };
const rawSleep = (ms) => new Promise((r) => { const id = ++timerSeq; timerWaits.set(id, r); timerWorker.postMessage({ id, ms }); });

class StopError extends Error {}
class SkipError extends Error {}      // do not retry this prompt
class LimitError extends Error {}     // ChatGPT usage limit
class SendError extends Error {}      // the prompt did not leave the box — try again in the same chat
const run = { active: false, paused: false, stop: false, startedAt: 0, doneAtStart: 0 };

async function wait(ms, label) {
  const end = Date.now() + ms;
  for (;;) {
    if (run.stop) throw new StopError('stopped');
    while (run.paused) { if (run.stop) throw new StopError('stopped'); await rawSleep(300); }
    const left = end - Date.now();
    if (left <= 0) return;
    if (label) setNow(label + ' — ' + Math.ceil(left / 1000) + 's');
    await rawSleep(Math.min(left, 500));
  }
}
const rand = (a, b) => { a = Number(a) || 0; b = Math.max(a, Number(b) || 0); return a + Math.random() * (b - a); };

function setNow(text) {
  $('#nowLine').textContent = text;
  overlay(text);
}

// ───────────────────────── licence ─────────────────────────
function fmtLeft(ms) {
  if (ms <= 0) return '0s';
  const d = Math.floor(ms / 864e5), h = Math.floor((ms % 864e5) / 36e5), m = Math.floor((ms % 36e5) / 6e4), s = Math.floor((ms % 6e4) / 1000);
  return (d ? d + 'd ' : '') + (d || h ? h + 'h ' : '') + m + 'm ' + String(s).padStart(2, '0') + 's';
}
const STATE_TEXT = {
  active: 'Active', pending: 'Waiting for activation', expired: 'Expired', blocked: 'Blocked by admin',
  nocredit: 'Image credits finished', maintenance: 'Under maintenance', update: 'Update required',
  'offline-expired': 'Needs internet to re-check', unknown: 'Cannot reach licence server',
  computer_limit: 'In use on another computer', in_use: 'Running in another browser', connect_required: 'Connect your account first'
};
const THEMES = { indigo: '#6d5efc', emerald: '#10b981', sunset: '#f97316', rose: '#f43f5e', ocean: '#0ea5e9', gold: '#eab308', violet: '#a855f7' };
const STATES = ['Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh', 'Delhi', 'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh',
  'Jammu and Kashmir', 'Jharkhand', 'Karnataka', 'Kerala', 'Ladakh', 'Madhya Pradesh', 'Maharashtra', 'Manipur', 'Meghalaya', 'Mizoram', 'Nagaland',
  'Odisha', 'Puducherry', 'Punjab', 'Rajasthan', 'Sikkim', 'Tamil Nadu', 'Telangana', 'Tripura', 'Uttar Pradesh', 'Uttarakhand', 'West Bengal',
  'Other Indian territory', 'Bangladesh', 'Outside India'];
let usedSince = 0;      // images saved since the last server check (credits are counted on the server)
let madeTotal = 0;
let me = null;
let chosenQr = '';

function creditsLeft() { return licence.credits == null ? null : Math.max(0, licence.credits - usedSince); }
let upUsedSince = 0;      // upscales done since the last server check
function upLeftNow() { return licence.upCredits == null ? null : Math.max(0, licence.upCredits - upUsedSince); }

function applyTheme() {
  const t = (licence.allowTheme && S.theme) || (srvConfig && srvConfig.theme) || 'indigo';
  const cur = THEMES[t] ? t : 'indigo';
  document.documentElement.dataset.theme = cur;
  const box = $('#themeSw');
  if (!box) return;
  box.innerHTML = Object.entries(THEMES).map(([k, c]) => `<button type="button" data-theme="${k}" title="${k}" class="${k === cur ? 'on' : ''}" style="background:${c}"></button>`).join('');
  box.classList.toggle('locked', !licence.allowTheme);
  $('#themeNote').textContent = licence.allowTheme ? 'Pick the colour you like.' : 'The theme colour is set by the admin. Some packages unlock your own choice.';
}

function renderLicence() {
  const left = licence.expiresAt - Date.now();
  if (licence.active && left <= 0) { licence.active = false; licence.state = 'expired'; }
  const cl = creditsLeft();
  if (licence.active && cl === 0) { licence.active = false; licence.state = 'nocredit'; }
  const ok = licence.active;
  $('#licDot').className = 'dot ' + (ok ? (left < 3 * 864e5 ? 'warn' : 'ok') : 'bad');
  $('#licPlan').textContent = ok ? (licence.plan || 'Active') : (STATE_TEXT[licence.state] || 'Not active');
  $('#licTimer').textContent = ok ? fmtLeft(left) + ' left' + (cl != null ? ' · ' + cl + ' img' : '') : 'Tap to activate';
  $('#lStatus').textContent = STATE_TEXT[licence.state] || licence.state;
  $('#lPlan').textContent = licence.plan || '—';
  $('#lLeft').textContent = ok ? fmtLeft(left) : '—';
  $('#lExp').textContent = licence.expiresAt ? new Date(licence.expiresAt).toLocaleString() : '—';
  const ul = upLeftNow();
  $('#lCred').textContent = licence.expiresAt ? (cl == null ? 'Unlimited' : cl + ' left') + ' · upscale ' + (ul == null ? 'unlimited' : ul + ' left') : '—';
  $('#lMade').textContent = madeTotal;
  $('#lNote').textContent = licence.state === 'unknown' ? 'This computer cannot reach the licence server (' + backendLabel + '). Check your internet. If it stays like this, send your Device ID to the admin on WhatsApp.' :
    licence.online === false ? 'Offline — using the last saved licence. Connect to the internet to refresh.' :
    (licence.requestedPackage ? 'Your request for "' + licence.requestedPackage + '" was received. It starts as soon as the admin approves it.' : '');

  // Gate: without an active licence only the Licence tab is usable.
  $$('#tabs button').forEach((b) => { b.disabled = !ok && b.dataset.tab !== 'licence'; });
  $('#gateBanner').classList.toggle('hide', ok);
  if (!ok) {
    const titles = { in_use: 'Your licence is running in another browser', connect_required: 'Connect your Skillful Freelance account', expired: 'Your subscription has ended', blocked: 'This device has been blocked', pending: 'Activation required', nocredit: 'Your image credits are finished', maintenance: 'The tool is under maintenance', update: 'Please update the extension', computer_limit: 'Your licence is in use on another computer' };
    $('#gateTitle').textContent = titles[licence.state] || 'Subscription required';
    const up = srvConfig && srvConfig.update;
    const acctUrl = srvConfig && srvConfig.pay && srvConfig.pay.accountUrl;
    $('#gateUpdate').classList.toggle('hide', !((licence.state === 'update' && up && up.url) || (licence.state === 'computer_limit' && acctUrl)));
    if (licence.state === 'computer_limit' && acctUrl) { $('#gateUpdate').href = acctUrl; $('#gateUpdate').textContent = 'Open My account'; }
    else if (up && up.url) { $('#gateUpdate').href = up.url; $('#gateUpdate').textContent = 'Download the new version'; }
    $('#gateText').textContent = licence.state === 'maintenance' ? (licence.message || 'Please try again a little later.')
      : licence.state === 'update' ? 'This version is too old. Download the new version, replace the extension folder, then press Reload on chrome://extensions.' + (up && up.note ? ' What is new: ' + up.note : '')
      : licence.state === 'computer_limit' ? (licence.message || 'Remove the old computer from My account on skillfulfreelance.com, then press Check again.') + (me && me.account ? ' Changes left this month: ' + (me.account.movesLeft || 0) + '.' : '')
      : licence.state === 'in_use' || licence.state === 'connect_required' ? (licence.message || '')
      : licence.state === 'blocked'
      ? 'Please contact the admin on WhatsApp to continue using Bulk Image Generator.'
      : 'To run Bulk Image Generator, buy a subscription or contact the admin. Fill in your details, choose a package below and send your request.';
    $('#gateMove').classList.toggle('hide', !(licence.state === 'computer_limit' && me && me.account && me.account.movesLeft > 0));
    $('#gateConnect').classList.toggle('hide', licence.state !== 'connect_required');
    showTab('licence');
    if (run.active && !run.stop) { run.stop = true; log('Stopped: licence is not active.', 'err'); }
  }
}

function renderMe() {
  const ref = srvConfig && srvConfig.referral;
  $('#refCard').classList.toggle('hide', !(ref && me && me.refCode));
  if (ref && me && me.refCode) {
    $('#refCode').textContent = me.refCode;
    const h = Number(ref.referrerHours) || 0;
    const bonus = h ? (h % 24 === 0 ? h / 24 + ' দিন' : h + ' ঘণ্টা') + ' ফ্রি সময়' : '';
    const cr = Number(ref.referrerCredits) ? ref.referrerCredits + ' ইমেজ ক্রেডিট' : '';
    $('#refText').textContent = `এই কোডটা বন্ধুকে দিন। সে রেজিস্ট্রেশনের সময় কোডটা লিখে প্যাকেজ চালু করলে আপনি পাবেন ${[bonus, cr].filter(Boolean).join(' ও ') || 'বোনাস'}। এখন পর্যন্ত আপনার রেফারে চালু হয়েছে: ${me.refCount || 0} জন।`;
  }
  // The referral code box is only for people who have not been activated yet.
  $('#refWrap').classList.toggle('hide', !ref || !!licence.expiresAt || !!(me && me.referredBy));
  if (me && me.account) {                       // connected: the details come from the website account
    for (const [id, v] of [['#uName', me.name], ['#uPhone', me.phone], ['#uEmail', me.email], ['#uState', me.state]]) if (v && document.activeElement !== $(id)) $(id).value = v;
  }
  if (me) {
    if (!$('#uName').value && me.name) $('#uName').value = me.name;
    if (!$('#uEmail').value && me.email) $('#uEmail').value = me.email;
    if (!$('#uState').value && me.state) $('#uState').value = me.state;
    if (!$('#uPhone').value && me.phone) $('#uPhone').value = me.phone;
  }
}

async function refreshLicence(force, claim) {
  licence = await checkLicence({ running: !!claim || (run.active && !run.paused), queueLeft: counts().left, force: force === true });
  usedSince = 0; upUsedSince = 0;
  me = licence.me || me;
  srvConfig = await serverConfig();
  renderLicence();
  renderPacks();
  renderMe();
  renderAccount();
  applyTheme();
  const a = srvConfig && srvConfig.announcement;
  $('#announce').classList.toggle('hide', !a);
  $('#announce').textContent = a ? '📢 ' + a : '';
  applyFlags();
  const up = srvConfig && srvConfig.update;
  const mine = chrome.runtime.getManifest().version;
  const newer = !!(up && up.latest && verCmp(up.latest, mine) > 0);
  $('#updateBar').classList.toggle('hide', !newer || licence.state === 'update');
  if (newer) {
    $('#updateText').textContent = '⬆️ New version ' + up.latest + ' is available (you have ' + mine + ').' + (up.note ? ' ' + up.note : '');
    $('#updateLink').classList.toggle('hide', !up.url);
    if (up.url) $('#updateLink').href = up.url;
    $('#updateNow').classList.toggle('hide', !up.url);
    showUpdatePopup(up, mine);
  }
  $('#gateUpdNow').classList.toggle('hide', !(licence.state === 'update' && up && up.url));
  guide.maybeShowOffer(srvConfig, acceptOffer);
}

function renderPacks() {
  const packs = (srvConfig && srvConfig.packages) || [];
  const cur = (srvConfig && srvConfig.currency) || '';
  if (!chosenPack && packs.length) chosenPack = (packs.find((p) => p.highlight) || packs.find((p) => /month/i.test(p.name)) || packs[0]).id;
  const priceHtml = (p) => guide.offerActive(p)
    ? `<i>${p.price ? '<s>' + esc(cur) + p.price + '</s>' : ''}${esc(cur)}${p.offerPrice}</i><em>Offer ends in <span data-ends="${p.offerEndsAt}">${guide.fmtLeft(p.offerEndsAt - Date.now())}</span></em>`
    : `<i>${p.price ? esc(cur) + p.price : 'Ask admin for price'}</i>`;
  const feats = (p) => {
    const list = String(p.features || '').split('\n').map((x) => x.trim()).filter(Boolean);
    const miss = (p.missing || []).length ? `<small class="pack-miss">Not included: ${esc(p.missing.join(', '))}</small>` : '';
  return (list.length ? '<ul>' + list.map((x) => `<li>${esc(x)}</li>`).join('') + '</ul>' : '') + miss;
  };
  $('#packs').innerHTML = packs.length
    ? packs.map((p) => `<button class="pack ${p.id === chosenPack ? 'on' : ''} ${guide.offerActive(p) ? 'offer' : ''} ${p.highlight ? 'hot' : ''}" data-pack="${esc(p.id)}">${p.badge || p.highlight ? '<u>' + esc(String(p.badge || 'Most popular').toUpperCase()) + '</u>' : ''}<b>${esc(p.name)}</b><span>${guide.durText(p.hours)} · ${p.credits > 0 ? p.credits + ' images' : 'unlimited images'} · ${p.upscales > 0 ? p.upscales + ' upscales' : 'unlimited upscales'}</span>${priceHtml(p)}${feats(p)}</button>`).join('')
    : '<div class="hint">Packages could not be loaded. You can still send your Device ID to the admin on WhatsApp.</div>';

  const sel = packs.find((p) => p.id === chosenPack);
  const qrs = (srvConfig && srvConfig.qrs) || [];
  // online payment (set in Super Admin): the main way to buy; QR + WhatsApp stay as the second way
  const online = payOnline() && packs.length > 0;
  $('#payOnlineBox').classList.toggle('hide', !online);
  if (online && sel) { const ep = guide.effectivePrice(sel); $('#payOnlineBtn').textContent = '💳 Pay online' + (ep ? ' ' + cur + ep : '') + ' — starts instantly'; }
  $('#payOr').classList.toggle('hide', !online);
  // with online payment on, the WhatsApp request button shows only when the admin allows buying on WhatsApp
  $('#sendReq').classList.toggle('hide', online && !!(srvConfig && srvConfig.pay) && srvConfig.pay.buyWa === false);
  $('#sendReq').className = (online ? 'btn ghost grow' : 'btn primary grow') + ($('#sendReq').classList.contains('hide') ? ' hide' : '');
  $('#payOr').classList.toggle('hide', !online || ($('#sendReq').classList.contains('hide') && !qrs.length));
  $('#sendReq').textContent = online ? 'Or send a request on WhatsApp' : 'Send request on WhatsApp';
  $('#payBox').classList.toggle('hide', !qrs.length);
  if (qrs.length) {
    const q = qrs.find((x) => x.id === chosenQr) || qrs[0];
    const ep = sel ? guide.effectivePrice(sel) : 0;
    const amt = ep ? cur + ep + ' — ' + sel.name + (guide.offerActive(sel) ? ' (offer)' : '') : (sel ? sel.name + ' — ask admin for price' : '');
    $('#payBox').innerHTML = (qrs.length > 1 ? '<div class="qtabs">' + qrs.map((x) => `<button type="button" data-qr="${esc(x.id)}" class="${x.id === q.id ? 'on' : ''}">${esc(x.label)}</button>`).join('') + '</div>' : '') +
      `<img id="payImg" alt="Payment QR code"><div><span>Scan to pay${qrs.length === 1 && q.label ? ' · ' + esc(q.label) : ''}</span><b>${esc(amt)}</b>${[['UPI ID', q.note], ['Name', q.payee], ['Number', q.phone]].filter((x) => x[1]).map((x) => `<p><span style="display:inline">${x[0]}:</span> ${esc(x[1])}</p>`).join('')}${q.details ? `<p>${esc(q.details)}</p>` : ''}
        <p class="hint">Pay the amount, then press the button below and send the payment screenshot on WhatsApp.</p></div>`;
    qrUrl(q).then((u) => { const im = $('#payImg'); if (im && u) im.src = u; }).catch(() => {});
  }
}

function verCmp(a, b) {
  const pa = String(a || '0').split('.').map(Number), pb = String(b || '0').split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) { const d = (pa[i] || 0) - (pb[i] || 0); if (d) return d > 0 ? 1 : -1; }
  return 0;
}
/** JPG quality: up to 100% when the package includes it, otherwise at most 90%. */
const saveQuality = () => (flagOn('maxQuality') ? S.quality : Math.min(S.quality, 90));
// Feature switches set by the admin (Super Admin → Control → Features) and by the student's package.
function flagOn(name) { const f = srvConfig && srvConfig.flags; return !f || f[name] !== false; }
function applyFlags() {
  const up = flagOn('upscale'), pm = flagOn('promptMaker'), svg = flagOn('svg'), qc = flagOn('qualityCheck');
  if (!up && S.upscale) { S.upscale = false; saveSettings(); }
  const upCard = $('#upOn') && $('#upOn').closest('.card');
  if (upCard) {
    $('#upOn').closest('label').classList.toggle('flag-off', !up);
    $('#upOpts').classList.toggle('flag-off', !up);
  }
  const quick = $('#quickUpscale'); if (quick) quick.closest('label').classList.toggle('flag-off', !up);
  const maker = $('#ideaBtn') && $('#ideaBtn').closest('.card'); if (maker) maker.classList.toggle('flag-off', !pm);
  const svgBox = $('[data-set="svg"]'); if (svgBox) svgBox.closest('label').classList.toggle('flag-off', !svg);
  const qcBox = $('[data-set="qualityCheck"]'); if (qcBox) qcBox.closest('label').classList.toggle('flag-off', !qc);
}

function runTour() {
  if (!licence.active) { toast('গাইড দেখতে আগে লাইসেন্স চালু করুন'); return; }
  guide.startTour(showTab, () => chrome.storage.local.set({ tourDone: true }));
}
// ── new version: pop-up once per version (and again after 12 hours), one-click update ──
function showUpdatePopup(up, mine, force) {
  if (!up || !up.url || run.active) return;
  if (!force && !$('#modal').classList.contains('hide')) return;
  let seen = {}; try { seen = JSON.parse(localStorage.getItem('sfUpdSeen') || '{}'); } catch { /* ignore */ }
  if (!force && seen.v === up.latest && Date.now() - seen.t < 12 * 3600e3) return;
  try { localStorage.setItem('sfUpdSeen', JSON.stringify({ v: up.latest, t: Date.now() })); } catch { /* ignore */ }
  const box = guide.openModal(`
    <div class="obadge">⬆️ নতুন আপডেট</div>
    <h2 style="margin:6px 0">নতুন ভার্সন ${esc(up.latest)} এসেছে</h2>
    <p class="hint">আপনার আছে ${esc(mine)}।${up.note ? ' নতুন যা আছে: ' + esc(up.note) : ''}</p>
    <button class="btn primary" id="updGo" style="width:100%;margin:10px 0">⚡ এক ক্লিকে আপডেট করুন</button>
    <p class="hint" id="updStep">প্রথমবার Extension-এর ফোল্ডারটা একবার বেছে দিতে হবে — যে ফোল্ডারটা chrome://extensions-এ "Load unpacked" করেছিলেন (SF-Bulk-Image-Generator)। পরের আপডেট থেকে আর লাগবে না। আপনার Device ID, লাইসেন্স আর সেটিং সব থাকবে।</p>
    <details style="margin-top:10px"><summary>নিজে হাতে আপডেট করতে চাইলে</summary>
      <ol class="hint" style="padding-left:18px;line-height:1.7">
        <li><a href="${esc(up.url)}" target="_blank" rel="noopener">নতুন ZIP ডাউনলোড করুন</a> আর Extract করুন।</li>
        <li>নতুন ফাইলগুলো কপি করে <b>পুরোনো ফোল্ডারেই</b> বসিয়ে দিন (Replace)। নতুন জায়গায় আলাদা ফোল্ডার Load করবেন না — তাহলে নতুন Device ID তৈরি হয়ে লাইসেন্স হারাবে।</li>
        <li>chrome://extensions খুলে Bulk Image Generator-এর 🔄 Reload চাপুন।</li>
      </ol></details>
    <button class="btn link" id="updLater">পরে করব</button>`, 'offer');
  box.querySelector('#updLater').onclick = guide.closeModal;
  box.querySelector('#updGo').onclick = () => runUpdate(up, box.querySelector('#updStep'));
}
async function runUpdate(up, stepEl) {
  if (run.active) { toast('আগে Run বন্ধ করুন, তারপর আপডেট করুন'); return; }
  const say = (m) => { if (stepEl) stepEl.textContent = m; else toast(m); };
  try {
    const { installUpdate } = await import('../lib/updater.js');
    const v = await installUpdate(up.url, async () => {
      say('যে ফোল্ডারটা chrome://extensions-এ Load unpacked করেছিলেন (SF-Bulk-Image-Generator), সেটা বেছে নিন…');
      try { return await window.showDirectoryPicker({ id: 'sf-ext-folder', mode: 'readwrite' }); } catch (e) { if (/security/i.test(String(e && e.message))) throw e; return null; }
    }, say);
    if (!v) say('ফোল্ডার বেছে না নেওয়ায় আপডেট হয়নি। আবার চাপুন, অথবা নিচের "নিজে হাতে" পদ্ধতি দেখুন।');
    else log('Updated to version ' + v + '.', 'ok');
  } catch (e) {
    say(/security/i.test(String(e && e.message)) ? 'এই ফোল্ডারটা Chrome নিরাপত্তার জন্য বাছতে দেয় না (যেমন Downloads, Desktop বা Documents নিজে)। আবার চাপুন আর তার ভেতরের SF-Bulk-Image-Generator ফোল্ডারটা বাছুন।' : 'আপডেট হয়নি: ' + (e.message || e) + ' — নিচের "নিজে হাতে আপডেট" ধাপগুলো দেখুন।');
    addError('Update failed: ' + String(e.message || e).slice(0, 40)).catch(() => {});
  }
}

// ── account + online payment ──
const payOnline = () => !!(srvConfig && srvConfig.pay && srvConfig.pay.online && srvConfig.pay.buyUrl);
function renderAccount() {
  const acc = me && me.account, pay = (srvConfig && srvConfig.pay) || {};
  $('#acctState').className = 'acct-state ' + (acc ? 'ok' : '');
  $('#acctState').textContent = acc
    ? '✅ Connected to ' + (acc.email || 'your account') + (acc.computers ? ' · computers ' + acc.used + ' of ' + acc.computers : '')
    : 'Not connected yet — connect so your licence stays safe if you re-install the extension or use another browser.';
  $('#connectBtn').classList.toggle('hide', !!acc || !pay.connectUrl);
  $('#acctLink').classList.toggle('hide', !pay.accountUrl);
  if (pay.accountUrl) $('#acctLink').href = pay.accountUrl;
  $('#acctCard').classList.toggle('hide', !pay.connectUrl && !acc);
}
// After opening the website (payment or connect), keep checking for a while so the change shows by itself.
let watchTimer = null;
function watchLicence(kind) {
  clearInterval(watchTimer);
  const startExp = licence.expiresAt || 0, end = Date.now() + 20 * 60000;
  watchTimer = setInterval(async () => {
    if (Date.now() > end) { clearInterval(watchTimer); return; }
    try { await refreshLicence(true); } catch { return; }
    if (kind === 'pay' && licence.active && licence.expiresAt > startExp) { clearInterval(watchTimer); toast('✅ Payment received — your licence is active'); log('Licence activated after online payment.', 'ok'); }
    if (kind === 'link' && me && me.account) { clearInterval(watchTimer); toast('✅ Connected to ' + (me.account.email || 'your account')); }
  }, 5000);
}
function openPay() {
  const pay = srvConfig && srvConfig.pay;
  if (!payOnline()) { toast('Online payment is not available right now'); return; }
  if (!chosenPack) { toast('Choose a package first'); return; }
  if (licence.active && licence.expiresAt - Date.now() > 24 * 3600e3) {
    const until = new Date(licence.expiresAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' });
    if (!confirm('আপনার "' + (licence.plan || 'প্যাকেজ') + '" এখনো চালু আছে — ' + until + ' পর্যন্ত।\n\nনতুন প্যাকেজ কিনলে তার সময় এই মেয়াদের সঙ্গে যোগ হবে (আগের মেয়াদ নষ্ট হবে না)। আনলিমিটেড প্ল্যান চালু থাকলে আনলিমিটেডই থাকবে।\n\nতবুও কিনতে চান?')) return;
  }
  const url = pay.buyUrl + '?p=' + encodeURIComponent(chosenPack) + '&d=' + encodeURIComponent(device.deviceId) + '&from=ext';
  window.open(url, '_blank', 'noopener');
  toast('Finish the payment in the new tab — this page updates by itself');
  watchLicence('pay');
}
async function connectAccount() {
  try {
    const r = await startLink();
    window.open(r.url, '_blank', 'noopener');
    toast('Sign in on the website and press "Connect" — this page updates by itself');
    watchLicence('link');
  } catch (e) { toast('Could not start: ' + (e.message || e)); }
}

// "Take this offer" in the pop-up: online payment when it is on; otherwise the WhatsApp request.
function acceptOffer(packId) {
  chosenPack = packId; renderPacks();
  if (payOnline()) { showTab('licence'); openPay(); return; }
  if (!$('#uName').value.trim() || !$('#uPhone').value.trim() || !$('#uState').value) {
    showTab('licence'); $('#uName').focus();
    toast('আপনার নাম, WhatsApp নম্বর ও State দিয়ে "Send request on WhatsApp" চাপুন');
    return;
  }
  sendRequest();
}

async function sendRequest() {
  const name = $('#uName').value.trim(), phone = $('#uPhone').value.trim(), email = $('#uEmail').value.trim(),
    state = $('#uState').value, refCode = $('#uRef').value.trim().toUpperCase();
  if (!name) { toast('Please type your name'); $('#uName').focus(); return; }
  if (phone.replace(/\D/g, '').length < 10) { toast('Please type your WhatsApp number'); $('#uPhone').focus(); return; }
  if (!state) { toast('Please choose your state'); $('#uState').focus(); return; }
  if (email && !/^\S+@\S+\.\S+$/.test(email)) { toast('That email does not look right'); $('#uEmail').focus(); return; }
  await chrome.storage.local.set({ userName: name, userPhone: phone, profile: { email, state, refCode } });
  const pack = ((srvConfig && srvConfig.packages) || []).find((p) => p.id === chosenPack);
  try {
    licence = await requestActivation({ name, phone, email, state, refCode }, chosenPack);
    me = licence.me || me;
    renderLicence(); renderMe();
  } catch { toast('Server not reachable — your request will go by WhatsApp only'); }
  const c$ = (srvConfig && srvConfig.currency) || '';
  const packLine = !pack ? 'Please suggest'
    : guide.offerActive(pack) ? `${pack.name} — OFFER ${c$}${pack.offerPrice}${pack.price ? ' (regular ' + c$ + pack.price + ')' : ''}`
    : pack.name + (pack.price ? ' (' + c$ + pack.price + ')' : '');
  const text = `Hello, I want to activate Bulk Image Generator.\nName: ${name}\nWhatsApp: ${phone}\nEmail: ${email || '-'}\nState: ${state}\nPackage: ${packLine}${refCode ? '\nReferral code: ' + refCode : ''}\nDevice ID: ${device.deviceId}`;
  window.open(whatsappLink(srvConfig && srvConfig.whatsapp, text), '_blank', 'noopener');
}

// ───────────────────────── AI prompt maker ─────────────────────────
let making = false;
function makerSeparator() {
  const c = String(S.customSep || '').trim();
  return c.length >= 3 && !/\s/.test(c) ? c : '-----';
}
async function makePrompts(importOnly) {
  if (making) return;
  if (run.active) { toast('Stop the run first'); return; }
  const idea = $('#ideaBox').value.trim();
  const count = Math.max(1, Math.min(200, Number($('#ideaCount').value) || 20));
  if (!importOnly && idea.length < 5) { toast('কী ধরনের ইমেজ চান তা আগে লিখুন'); $('#ideaBox').focus(); return; }
  const sep = makerSeparator();
  const line = $('#ideaLine');
  const say = (m) => { line.classList.remove('hide'); line.textContent = m; overlay(m); };
  // prompts may be in a code block, in the plain answer, or in a canvas panel
  const read = (r) => { for (const t of [r && r.code, r && r.text, r && r.canvas]) { const l = parseMadePrompts(t || '', sep); if (l.length) return l; } return []; };
  making = true; $('#ideaBtn').disabled = true;
  try {
    await findTab(true);
    await waitReady(40000);
    if (!importOnly) {
      // write the prompts in a fresh chat (inside the same project, if one is open): no old messages to confuse the reading
      let st0 = await cs('status');
      if (st0 && (st0.assistantCount > 0 || st0.userCount > 0) && !st0.streaming) {
        say('নতুন চ্যাট খোলা হচ্ছে…');
        try { await cs('newChat'); } catch { /* the page is reloading */ }
        await rawSleep(2500);
        await waitReady(40000);
      }
      let st = await cs('status');
      const busyEnd = Date.now() + 120000;
      while (st.streaming && Date.now() < busyEnd) { say('ChatGPT আগের উত্তর শেষ করছে…'); await rawSleep(2000); st = await cs('status'); }
      const before = await cs('lastText');
      say('ChatGPT-কে প্রম্পট লিখতে বলা হচ্ছে…');
      const sent = await cs('send', { text: promptMakerMessage(idea, count, (MODES[S.mode] || MODES.photo).label, S.format === 'png' && S.transparent, sep) });
      if (!sent || !sent.ok) {
        // last resort: the person pastes it once, the import button reads the answer
        try { await navigator.clipboard.writeText(promptMakerMessage(idea, count, (MODES[S.mode] || MODES.photo).label, S.format === 'png' && S.transparent, sep)); } catch { /* clipboard blocked */ }
        addError('Prompt maker: send failed — ' + ((sent && sent.error) || 'no answer')).catch(() => {});
        throw new Error('ChatGPT-তে নিজে থেকে পাঠানো গেল না (' + ((sent && sent.error) || 'unknown') + ')। অনুরোধটা কপি করা আছে — ChatGPT-তে Paste করে Send চাপুন, উত্তর এলে নিচের "Import prompts" চাপুন');
      }
      const end = Date.now() + 8 * 60000;
      let lastLen = -1, stable = 0, sawAnswer = false;
      for (;;) {
        await rawSleep(1500);
        if (Date.now() > end) throw new Error('ChatGPT অনেক সময় নিচ্ছে');
        let r; try { r = await cs('lastText'); } catch { continue; }
        const mine = r.userCount > before.userCount;       // the answer to OUR message
        const got = mine ? read(r).length : 0;
        if (mine && (r.text || '').length > 0) sawAnswer = true;
        say(r.streaming ? 'ChatGPT লিখছে… ' + got + ' টা প্রম্পট পাওয়া গেছে' : sawAnswer ? 'উত্তর পড়া হচ্ছে… ' + got + ' টা প্রম্পট' : 'ChatGPT-র উত্তরের অপেক্ষা…');
        if (mine && r.images > 0 && !got) throw new Error('ChatGPT প্রম্পট না লিখে ইমেজ বানাতে শুরু করেছে। ChatGPT-তে Stop চেপে আবার চেষ্টা করুন');
        if (mine && !r.streaming && sawAnswer) {
          const len = (r.code || r.text).length;
          stable = len === lastLen ? stable + 1 : 0;
          lastLen = len;
          if (stable >= 2) break;
        }
      }
    }
    const res = await cs('lastText');
    const list = read(res);
    if (!list.length) {
      say('ChatGPT-র উত্তর থেকে প্রম্পট ধরা যায়নি। উত্তরটা কপি করে নিচের বক্সে পেস্ট করুন, অথবা আবার চেষ্টা করুন।');
      log('AI prompt maker: could not read prompts from the ChatGPT answer (' + ((res && res.text) || '').length + ' characters seen).', 'warnl');
      addError('Prompt maker: answer not readable (' + ((res && res.text) || '').length + ' chars)').catch(() => {});
      return;
    }
    const box = $('#promptBox');
    const joiner = '\n' + sep + '\n';
    box.value = (box.value.trim() ? box.value.trim() + joiner : '') + list.join(joiner);
    S.separator = 'custom'; S.customSep = sep; saveSettings(); applySettingsToUI();
    say(`${list.length} টা প্রম্পট নিচের বক্সে এসেছে, প্রতিটার মাঝে "${sep}" সেপারেটর দেওয়া। দেখে নিয়ে "Load prompts into queue" চাপুন।`);
    log(`AI prompt maker: imported ${list.length} prompt(s), separator "${sep}".`, 'ok');
    box.scrollIntoView({ block: 'center' });
  } catch (e) {
    if (!importOnly) {
      // The answer may still be usable even if waiting failed.
      try {
        const res = await cs('lastText');
        const list = read(res);
        if (list.length) {
          const box = $('#promptBox'); const joiner = '\n' + sep + '\n';
          box.value = (box.value.trim() ? box.value.trim() + joiner : '') + list.join(joiner);
          S.separator = 'custom'; S.customSep = sep; saveSettings(); applySettingsToUI();
          say(`${list.length} টা প্রম্পট নিচের বক্সে এসেছে।`);
          return;
        }
      } catch { /* fall through to the message below */ }
    }
    addError('Prompt maker: ' + String(e.message || e).slice(0, 50)).catch(() => {});
    say('হয়নি: ' + e.message + '। ChatGPT-র উত্তর তৈরি হয়ে থাকলে "Import prompts from the open ChatGPT chat" চাপুন।');
    log('AI prompt maker failed: ' + e.message, 'err');
  } finally {
    making = false; $('#ideaBtn').disabled = false;
    setTimeout(() => { lastOverlay = 'x'; overlay(''); }, 6000);
  }
}

// ───────────────────────── ChatGPT tab driver ─────────────────────────
let tabId = null;
async function findTab(create) {
  if (tabId != null) {
    try { const t = await chrome.tabs.get(tabId); if (t && /^https:\/\/chatgpt\.com\//.test(t.url || '')) return tabId; } catch { /* closed */ }
  }
  const tabs = await chrome.tabs.query({ url: 'https://chatgpt.com/*' });
  if (tabs.length) {
    tabs.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
    tabId = tabs[0].id;
    keepAwake(tabId);
    return tabId;
  }
  if (!create) return null;
  const t = await chrome.tabs.create({ url: 'https://chatgpt.com/', active: false });
  tabId = t.id;
  keepAwake(tabId);
  return tabId;
}
/** Chrome may put a background tab to sleep (Memory Saver) — the ChatGPT tab must stay awake during a run. */
function keepAwake(id) { try { chrome.tabs.update(id, { autoDiscardable: false }).catch(() => {}); } catch { /* old Chrome */ } }
let hiddenWarned = false, lastHidden = false;
/** A ChatGPT tab that is not on screen is slowed down by Chrome — tell the student once per run. */
function noteHidden(st) {
  if (st) lastHidden = !!st.hidden;
  if (!st || !st.hidden || hiddenWarned) return;
  hiddenWarned = true;
  log('ChatGPT tab is in the background — Chrome slows it down, so prompts may not send. Best: open ChatGPT in its own window next to this one (side by side) and keep both visible.', 'warnl');
}

async function cs(cmd, extra) {
  const id = await findTab(false);
  if (id == null) throw new Error('ChatGPT tab was closed');
  const msg = Object.assign({ target: 'sf-driver', cmd }, extra || {});
  try {
    const r = await chrome.tabs.sendMessage(id, msg);
    if (r) return r;
  } catch { /* driver not in the page yet */ }
  try { await chrome.scripting.executeScript({ target: { tabId: id }, files: ['content/chatgpt.js'] }); } catch { /* page still loading */ }
  await rawSleep(300);
  return chrome.tabs.sendMessage(id, msg);
}

let lastOverlay = '';
function overlay(text) {
  if (tabId == null || text === lastOverlay) return;
  lastOverlay = text;
  const c = counts();
  const label = text ? `SF Bulk ${c.done}/${queue.length} · ${text}`.slice(0, 80) : '';
  chrome.tabs.sendMessage(tabId, { target: 'sf-driver', cmd: 'overlay', text: label, state: run.paused ? 'paused' : 'run' }).catch(() => {});
}

async function waitReady(maxMs = 60000) {
  const { selectors } = await chrome.storage.local.get('selectors');
  const end = Date.now() + maxMs;
  let last = null;
  while (Date.now() < end) {
    try {
      last = await cs('ping', { selectors });
      noteHidden(last);
      if (last && last.ready) return last;
      if (last && last.loggedOut) throw new SkipError('You are not logged in to ChatGPT. Log in in the ChatGPT tab, then press Start again.');
    } catch (e) { if (e instanceof SkipError) throw e; }
    await wait(1200, 'Waiting for ChatGPT to load');
  }
  throw new Error('ChatGPT page did not become ready' + (last && last.hidden ? ' (tab in background)' : ''));
}

async function openNewChat() {
  setNow('Opening a new chat');
  try { await cs('newChat'); } catch { /* page is navigating */ }
  await wait(1500);
  await waitReady();
}

async function fetchImageBlob(src) {
  try {
    const r = await fetch(src, { credentials: 'include' });
    if (r.ok) { const b = await r.blob(); if (b.size > 2000 && /^image\//.test(b.type)) return b; }
  } catch { /* fall back to fetching inside the page */ }
  const r = await cs('fetchImage', { src });
  if (!r || !r.ok) throw new Error('Could not download the image (' + ((r && r.error) || 'no response') + ')');
  return (await fetch(r.dataUrl)).blob();
}

async function waitForImage(baseKeys, baseAssistant) {
  const start = Date.now();
  const timeout = Math.max(60, Number(S.genTimeout) || 300) * 1000;
  let idleSince = null, stableKey = '', stableHits = 0;
  for (;;) {
    await wait(1500);
    let st;
    try { st = await cs('status'); } catch { continue; }
    const fresh = st.images.filter((i) => !baseKeys.has(i.key));
    const secs = Math.round((Date.now() - start) / 1000);
    setNow('ChatGPT is creating the image — ' + secs + 's');
    if (fresh.length && !st.streaming && fresh.every((i) => i.complete)) {
      const k = fresh.map((i) => i.key).join('|');
      stableHits = k === stableKey ? stableHits + 1 : 1;
      stableKey = k;
      if (stableHits >= 2) return fresh;
    } else { stableHits = 0; }
    const answered = st.assistantCount > baseAssistant;
    if (!st.streaming && !fresh.length && !st.busyHint) {
      idleSince = idleSince || Date.now();
      const idle = Date.now() - idleSince;
      if (answered && idle > 6000 && st.limitHint) throw new LimitError(st.lastText.slice(0, 160));
      if (answered && idle > 6000 && /content polic|violat/i.test(st.lastText)) throw new SkipError('ChatGPT declined this prompt: ' + st.lastText.slice(0, 140));
      if (answered && idle > 6000 && st.toolFailHint) throw new Error('ChatGPT image tool failed: ' + st.lastText.slice(0, 140));
      if (answered && idle > 8000 && st.refuseHint) throw new SkipError('ChatGPT declined this prompt: ' + st.lastText.slice(0, 140));
      if (idle > 45000) throw new Error(answered ? 'ChatGPT answered without an image: ' + st.lastText.slice(0, 120) : 'ChatGPT did not respond');
    } else { idleSince = null; }
    if (Date.now() - start > timeout) throw new Error('Timed out after ' + Math.round(timeout / 1000) + 's');
  }
}

// ───────────────────────── saving ─────────────────────────
function idb() {
  return new Promise((res, rej) => {
    const r = indexedDB.open('sf-bulk', 1);
    r.onupgradeneeded = () => r.result.createObjectStore('kv');
    r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
  });
}
async function idbGet(k) { const d = await idb(); return new Promise((res) => { const q = d.transaction('kv').objectStore('kv').get(k); q.onsuccess = () => res(q.result); q.onerror = () => res(null); }); }
async function idbSet(k, v) { const d = await idb(); return new Promise((res) => { const tx = d.transaction('kv', 'readwrite'); tx.objectStore('kv').put(v, k); tx.oncomplete = res; tx.onerror = res; }); }

async function dirReady(askUser) {
  if (!dirHandle) return false;
  try {
    let p = await dirHandle.queryPermission({ mode: 'readwrite' });
    if (p !== 'granted' && askUser) p = await dirHandle.requestPermission({ mode: 'readwrite' });
    return p === 'granted';
  } catch { return false; }
}
async function renderDir() {
  if (dirHandle) $('#dirLine').textContent = 'Saving to folder: ' + dirHandle.name + ((await dirReady(false)) ? '' : ' (permission will be asked when you press Start)');
  else $('#dirLine').textContent = 'Saving to: Downloads' + (S.subfolder ? ' / ' + S.subfolder : '');
}

async function saveFile(blob, name) {
  if (dirHandle && (await dirReady(false))) {
    let final = name;
    const dot = name.lastIndexOf('.');
    for (let i = 1; i < 500; i++) {
      try { await dirHandle.getFileHandle(final); final = name.slice(0, dot) + '_' + i + name.slice(dot); } catch { break; }
    }
    const fh = await dirHandle.getFileHandle(final, { create: true });
    const w = await fh.createWritable();
    await w.write(blob);
    await w.close();
    return final;
  }
  const sub = String(S.subfolder || '').replace(/[\\:*?"<>|]+/g, '').replace(/^[/.\s]+|[/.\s]+$/g, '');
  const url = URL.createObjectURL(blob);
  try {
    const id = await chrome.downloads.download({ url, filename: (sub ? sub + '/' : '') + name, conflictAction: 'uniquify', saveAs: false });
    const finalName = await new Promise((resolve, reject) => {
      const timer = setTimeout(() => { chrome.downloads.onChanged.removeListener(on); reject(new Error('Download did not finish')); }, 120000);
      function on(d) {
        if (d.id !== id || !d.state) return;
        if (d.state.current === 'complete' || d.state.current === 'interrupted') {
          clearTimeout(timer); chrome.downloads.onChanged.removeListener(on);
          if (d.state.current === 'complete') chrome.downloads.search({ id }).then((r) => resolve(((r[0] && r[0].filename) || name).split(/[\\/]/).pop()));
          else reject(new Error('Download was interrupted'));
        }
      }
      chrome.downloads.onChanged.addListener(on);
      chrome.downloads.search({ id }).then((r) => { if (r[0] && r[0].state === 'complete') on({ id, state: { current: 'complete' } }); });
    });
    return finalName;
  } finally { setTimeout(() => URL.revokeObjectURL(url), 30000); }
}

// ───────────────────────── image pipeline ─────────────────────────
const sessionHashes = [];   // { hash, number }
let upscaleChain = Promise.resolve();
const pipelines = new Set();

async function pipeline(item, blob) {
  const ext = S.format === 'png' ? '.png' : S.format === 'webp' ? '.webp' : '.jpg';
  let canvas = await blobToCanvas(blob);
  const base = buildFileName(S.nameTemplate, { number: item.number, pad: S.pad, prompt: item.prompt, prefix: S.namePrefix, w: canvas.width, h: canvas.height });

  const hash = dHash(canvas);
  const twin = sessionHashes.find((h) => hamming(h.hash, hash) <= 6);
  if (twin) { item.similar = twin.number; log(`#${item.number} looks very similar to #${twin.number} — submit only one of them to Adobe Stock.`, 'warnl'); }
  sessionHashes.push({ hash, number: item.number });

  if (S.upscale && S.keepOriginal) {
    await saveFile(await canvasToBlob(canvas, S.format, saveQuality()), base + '_original' + ext);
  }
  let upscaled = false;
  const origSize = { w: canvas.width, h: canvas.height };
  const upOk = upLeftNow() !== 0;
  if (S.upscale && flagOn('upscale') && !upOk && !run.upWarned) { run.upWarned = true; log('Your AI upscale credits are finished — images are saved in their original size. Buy a package with more upscales (Licence tab).', 'warnl'); toast('Upscale credits finished — saving original size'); }
  if (S.upscale && flagOn('upscale') && upOk) {
    upUsedSince++;              // counted now so two parallel jobs cannot go over the limit
    item.status = 'upscale-wait'; renderQueue();
    const job = upscaleChain.then(async () => {
      if (run.stop) throw new StopError('stopped');
      item.status = 'upscaling'; renderQueue();
      const t0 = Date.now();
      const r = await upscaleCanvas(canvas, {
        scale: Number(S.upScale), model: S.upModel, backend: 'auto', strength: Number(S.upStrength),
        onProgress: (p) => { item.progress = Math.round((p.done / p.total) * 100); renderQueueSoon(); }
      });
      log(`#${item.number} upscaled ${S.upScale}× to ${r.canvas.width}×${r.canvas.height} in ${Math.round((Date.now() - t0) / 1000)}s (${r.backend === 'webgpu' ? 'graphics card' : 'CPU'})`);
      return r.canvas;
    });
    upscaleChain = job.catch(() => {});
    try { canvas = await job; upscaled = true; }
    catch (e) {
      upUsedSince = Math.max(0, upUsedSince - 1);
      if (e instanceof StopError) throw e;
      log(`#${item.number} upscale failed (${e.message}) — saving the original size instead.`, 'err');
    }
  }
  item.status = 'saving'; renderQueue();
  const out = await canvasToBlob(canvas, S.format, saveQuality());
  if (S.qualityCheck && flagOn('qualityCheck')) item.report = analyzeQuality(canvas, out.size, S.format, S.mode, S.format === 'png' && hasAlpha(canvas), upscaled ? { upscaledFrom: origSize } : {});
  item.file = await saveFile(out, base + ext);
  if (S.mode === 'icon' && S.svg && flagOn('svg')) {
    try { await saveFile(new Blob([vectorize(canvas, 8)], { type: 'image/svg+xml' }), base + '.svg'); }
    catch (e) { log(`#${item.number} SVG trace failed: ${e.message}`, 'warnl'); }
  }
  try {
    const k = Math.min(1, 900 / Math.max(canvas.width, canvas.height));
    const pv = k < 1 ? resample(canvas, Math.round(canvas.width * k), Math.round(canvas.height * k)) : canvas;
    if (item.preview) URL.revokeObjectURL(item.preview);
    item.preview = URL.createObjectURL(await canvasToBlob(pv, 'jpg', 85));
  } catch { /* preview is optional */ }
  item.status = 'done'; item.error = ''; item.progress = 0;
  await addStat('generated'); if (upscaled) await addStat('upscaled');
  usedSince++; madeTotal++; chrome.storage.local.set({ madeTotal });
  const rep = item.report ? ` · Adobe check ${item.report.score}/100 (${item.report.verdict})` : '';
  log(`#${item.number} saved as ${item.file}${rep}`, 'ok');
  if (item.report) item.report.checks.filter((c) => !c.ok).forEach((c) => log(`   ↳ ${c.label}: ${c.detail}`, 'warnl'));
  renderQueue(); persistSoon();
}

// ───────────────────────── job runner ─────────────────────────
async function processItem(item, index) {
  const maxAttempts = 1 + Math.max(0, Number(S.retries) || 0);
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    item.attempts = attempt; item.status = 'sending'; item.error = ''; renderQueue();
    try {
      let st = await waitReady();
      const busyEnd = Date.now() + 180000;
      while (st.streaming && Date.now() < busyEnd) { await wait(2000, 'Waiting for ChatGPT to finish its current answer'); st = await cs('status'); }
      const baseKeys = new Set(st.images.map((i) => i.key));
      setNow(`Sending prompt #${item.number}`);
      const sent = await cs('send', { text: buildMessage(item.prompt, S, index) });
      if (!sent || !sent.ok) { if (sent && sent.hidden) noteHidden(sent); throw new SendError(((sent && sent.error) || 'Could not send the prompt').replace(/\.$/, '') + (sent && sent.hidden ? ' (tab in background)' : '')); }
      item.status = 'generating'; renderQueue();
      await waitForImage(baseKeys, st.assistantCount);

      item.status = 'downloading'; renderQueue();
      await wait(rand(S.dlMin, S.dlMax) * 1000, 'Image ready — waiting before download');
      const now = await cs('status');
      const fresh = now.images.filter((i) => !baseKeys.has(i.key) && i.complete);
      if (!fresh.length) throw new Error('The image disappeared before it could be downloaded');
      const pick = fresh.sort((a, b) => b.w * b.h - a.w * a.h)[0];
      setNow(`Downloading image #${item.number}`);
      const blob = await fetchImageBlob(pick.src);

      const p = pipeline(item, blob).catch((e) => {
        if (e instanceof StopError) { item.status = 'pending'; return; }
        item.status = 'failed'; item.error = e.message; addStat('failed');
        log(`#${item.number} could not be saved: ${e.message}`, 'err'); renderQueue();
      }).finally(() => pipelines.delete(p));
      pipelines.add(p);
      if (!S.upscale) await p;                       // download fully finished before the next prompt
      return true;
    } catch (e) {
      if (e instanceof StopError) { item.status = 'pending'; throw e; }
      item.error = e.message;
      log(`#${item.number} attempt ${attempt}/${maxAttempts} failed: ${e.message}`, 'err');
      addError((e instanceof SendError ? 'Send: ' : '') + String(e.message || '').split(':')[0] + (/did not respond/.test(e.message || '') && lastHidden ? ' (tab in background)' : ''));
      if (e instanceof SkipError) break;
      if (e instanceof LimitError) {
        item.status = 'pending'; renderQueue();
        log(`ChatGPT limit reached — pausing ${S.limitMinutes} minutes, then continuing automatically.`, 'warnl');
        await wait(Math.max(1, Number(S.limitMinutes) || 20) * 60000, 'ChatGPT limit reached — waiting');
      } else if (attempt < maxAttempts) {
        item.status = 'retry'; renderQueue();
        if (e instanceof SendError) {
          // the chat itself is fine — the text just did not go out. Try again in the SAME chat.
          await wait(4000, `Sending #${item.number} again`);
        } else {
          await wait(Math.max(5, Number(S.retryDelay) || 20) * 1000, `Retrying #${item.number} soon`);
          // a new chat only when the image itself failed, and only if the student allows it
          if (!S.stayInChat) { try { await openNewChat(); } catch (e2) { if (e2 instanceof StopError) { item.status = 'pending'; throw e2; } } }
        }
      }
    }
  }
  item.status = 'failed'; renderQueue(); persistSoon();
  await addStat('failed');
  if (!S.stayInChat) run.freshChat = true;       // a chat where generation failed tends to keep failing
  return false;
}

function counts() {
  let done = 0, failed = 0, left = 0;
  for (const i of queue) { if (i.status === 'done') done++; else if (i.status === 'failed') failed++; else left++; }
  return { done, failed, left };
}

async function start() {
  if (run.active) { if (run.paused) togglePause(); return; }
  if (!queue.some((i) => i.status === 'pending')) { toast('Load prompts first'); return; }
  try { await refreshLicence(true, true); } catch { /* offline: the saved licence decides */ }
  if (!licence.active) { showTab('licence'); toast(STATE_TEXT[licence.state] || 'Licence is not active'); return; }
  run.upWarned = false;
  if (dirHandle && !(await dirReady(true))) { toast('Folder permission was not given — files will go to Downloads'); }
  renderDir();

  run.active = true; run.paused = false; run.stop = false; run.startedAt = Date.now(); run.doneAtStart = counts().done;
  setButtons();
  log('Started.', 'ok');
  refreshLicence(true).catch(() => {});
  let retriedFailed = false, sinceBreak = 0, sinceChat = 0, first = true;
  try {
    await findTab(true);
    await waitReady();
    await wait(1500, 'Getting ChatGPT ready');      // a just-loaded page may not accept the first prompt yet
    for (;;) {
      const idx = queue.findIndex((i) => i.status === 'pending');
      if (idx < 0) {
        await Promise.allSettled([...pipelines]);
        if (S.autoRetryFailed && !retriedFailed && queue.some((i) => i.status === 'failed')) {
          retriedFailed = true;
          const n = queue.filter((i) => i.status === 'failed').length;
          queue.forEach((i) => { if (i.status === 'failed') i.status = 'pending'; });
          log(`Queue finished. Trying ${n} failed prompt(s) one more time.`, 'warnl');
          renderQueue();
          continue;
        }
        break;
      }
      if (!licence.active) throw new StopError('licence');
      if (creditsLeft() != null && creditsLeft() - pipelines.size <= 0) throw new Error('Image credits finished — renew your plan to continue.');
      if (!first) await wait(rand(S.nextMin, S.nextMax) * 1000, 'Waiting before the next prompt');
      if (Number(S.breakEvery) > 0 && sinceBreak >= Number(S.breakEvery)) {
        log(`Taking a ${S.breakMinutes} minute break after ${sinceBreak} images.`);
        await wait(Math.max(1, Number(S.breakMinutes) || 10) * 60000, 'Long break');
        sinceBreak = 0;
      }
      if (!S.stayInChat && (run.freshChat || (Number(S.newChatEvery) > 0 && sinceChat >= Number(S.newChatEvery)))) { await openNewChat(); sinceChat = 0; run.freshChat = false; }
      while (pipelines.size > 2) await wait(1000, 'Waiting for upscaling to catch up');
      await processItem(queue[idx], idx);
      first = false; sinceBreak++; sinceChat++;
      renderQueue(); persistSoon();
    }
    const c = counts();
    log(`All done: ${c.done} saved, ${c.failed} failed.`, 'ok');
    setNow(`Finished — ${c.done} saved, ${c.failed} failed.`);
  } catch (e) {
    if (e instanceof StopError) { log('Stopped.', 'warnl'); setNow('Stopped. Press Start to continue from where you left off.'); }
    else { log('Stopped because of an error: ' + e.message, 'err'); setNow('Stopped: ' + e.message); }
  } finally {
    run.active = false; run.paused = false; run.stop = false;
    queue.forEach((i) => { if (!['done', 'failed', 'pending', 'upscale-wait', 'upscaling', 'saving'].includes(i.status)) i.status = 'pending'; });
    setButtons(); renderQueue(); persistSoon();
    setTimeout(() => { lastOverlay = 'x'; overlay(''); }, 6000);
    checkLicence().then((l) => { licence = l; renderLicence(); });
  }
}

function togglePause() {
  if (!run.active) return;
  run.paused = !run.paused;
  log(run.paused ? 'Paused.' : 'Resumed.');
  if (run.paused) setNow('Paused. The current image will finish, then nothing new is sent.');
  setButtons();
}
function stop() {
  if (!run.active) return;
  run.stop = true;
  setNow('Stopping…');
}
function setButtons() {
  $('#startBtn').textContent = run.active ? (run.paused ? '▶ Resume' : 'Running…') : '▶ Start';
  $('#startBtn').disabled = run.active && !run.paused;
  $('#pauseBtn').disabled = !run.active;
  $('#pauseBtn').textContent = run.paused ? 'Resume' : 'Pause';
  $('#stopBtn').disabled = !run.active;
}

// ───────────────────────── queue UI ─────────────────────────
const CHIP = {
  pending: ['Waiting', ''], sending: ['Sending', 'run'], generating: ['Generating', 'run'], downloading: ['Downloading', 'run'],
  'upscale-wait': ['Upscale queued', 'up'], upscaling: ['Upscaling', 'up'], saving: ['Saving', 'run'], retry: ['Retrying', 'run'],
  done: ['Done', 'done'], failed: ['Failed', 'failed']
};
let rqTimer = null;
function renderQueueSoon() { if (!rqTimer) rqTimer = setTimeout(() => { rqTimer = null; renderQueue(); }, 400); }
function renderQueue() {
  const c = counts();
  $('#cDone').textContent = c.done; $('#cFail').textContent = c.failed; $('#cLeft').textContent = c.left;
  $('#queueCount').textContent = queue.length ? queue.length + ' prompts in queue' : 'Queue is empty';
  $('#bar').style.width = queue.length ? ((c.done + c.failed) / queue.length) * 100 + '%' : '0';
  const doneNow = c.done - run.doneAtStart;
  if (run.active && doneNow > 0 && c.left > 0) {
    const per = (Date.now() - run.startedAt) / doneNow;
    const mins = Math.round((per * c.left) / 60000);
    $('#eta').textContent = '≈ ' + (mins >= 60 ? Math.floor(mins / 60) + 'h ' + (mins % 60) + 'm' : mins + ' min') + ' remaining';
  } else $('#eta').textContent = '';
  if (!queue.length) { $('#queue').innerHTML = '<div class="empty">Load prompts to see them here.</div>'; return; }
  $('#queue').innerHTML = queue.map((i) => {
    const [label, cls] = CHIP[i.status] || [i.status, ''];
    const pct = i.status === 'upscaling' && i.progress ? ' ' + i.progress + '%' : '';
    const sc = i.report ? `<span class="score ${i.report.score >= 80 ? 'g' : i.report.score >= 60 ? 'y' : 'r'}" title="${esc(i.report.checks.map((k) => (k.ok ? '✓ ' : '✗ ') + k.label + ': ' + k.detail).join('\n'))}">Adobe ${i.report.score}</span>` : '';
    const sub = i.error && i.status !== 'done' ? `<small class="e">${esc(i.error)}</small>`
      : i.file ? `<small>${esc(i.file)}${i.report ? ' · ' + i.report.width + '×' + i.report.height + ' · ' + esc(i.report.verdict) : ''}${i.similar ? ' · similar to #' + i.similar : ''}</small>` : '';
    const th = i.preview ? `<img class="th" src="${i.preview}" alt="">` : '<span class="th"></span>';
    return `<div class="qi" data-id="${esc(i.id)}"><span class="n">${i.number}</span>${th}<div class="p"><div title="${esc(i.prompt)}">${esc(i.prompt)}</div>${sub}</div><span><span class="chip ${cls}">${label}${pct}</span>${sc}</span></div>`;
  }).join('');
}

function currentPrompts() {
  return parsePrompts($('#promptBox').value, S.separator, S.customSep, S.stripNumbers);
}
function updateLiveCount() {
  const n = currentPrompts().length;
  $('#liveCount').textContent = n + (n === 1 ? ' prompt' : ' prompts') + ' found';
}
function loadPrompts() {
  const list = currentPrompts();
  if (!list.length) { toast('No prompts found — paste them in the box first'); return; }
  const base = queue.length ? Math.max(...queue.map((i) => i.number)) + 1 : Math.max(0, Number(S.startNumber) || 1);
  list.forEach((p, k) => queue.push({ id: Date.now() + '-' + k, prompt: p, number: base + k, status: 'pending', attempts: 0, error: '', file: '' }));
  const dups = findNearDuplicates(queue.map((i) => i.prompt));
  const w = $('#dupWarn');
  w.classList.toggle('hide', !dups.length);
  if (dups.length) {
    const ex = dups.slice(0, 3).map(([a, b]) => '#' + queue[a].number + ' & #' + queue[b].number).join(', ');
    w.textContent = `${dups.length} pair(s) of prompts are almost the same (${ex}${dups.length > 3 ? ', …' : ''}). Adobe Stock refuses near-identical images — make each prompt a clearly different idea.`;
  }
  $('#promptBox').value = '';
  updateLiveCount();
  log(`Loaded ${list.length} prompt(s). Queue now has ${queue.length}.`);
  renderQueue(); persistSoon();
  toast(list.length + ' prompts loaded');
}

// ───────────────────────── settings UI ─────────────────────────
function fillSelect(el, obj) { el.innerHTML = Object.entries(obj).map(([k, v]) => `<option value="${k}">${esc(v.label)}</option>`).join(''); }

function applySettingsToUI() {
  $$('[data-set]').forEach((el) => {
    const v = S[el.dataset.set];
    if (el.type === 'checkbox') el.checked = !!v; else el.value = v;
  });
  refreshDerived();
}
function refreshDerived() {
  $('#customSepWrap').classList.toggle('hide', S.separator !== 'custom');
  $('#sepHint').textContent = (SEPARATORS[S.separator] || SEPARATORS.line).hint;
  $('#upOpts').classList.toggle('hide', !S.upscale);
  $('#trWrap').classList.toggle('hide', S.format !== 'png');
  applyTheme();
  $('#qVal').textContent = S.quality; $('#sVal').textContent = S.upStrength + '%';
  $('#quickUpscale').value = S.upscale ? String(S.upScale) : 'off';
  const presets = [...$('#namePreset').options].map((o) => o.value);
  $('#namePreset').value = presets.includes(S.nameTemplate) ? S.nameTemplate : 'custom';
  $('#tplWrap').classList.toggle('hide', $('#namePreset').value !== 'custom');
  $('#prefixWrap').classList.toggle('hide', !/\{prefix\}/.test(S.nameTemplate));
  const ext = S.format === 'png' ? '.png' : S.format === 'webp' ? '.webp' : '.jpg';
  $('#nameExample').textContent = buildFileName(S.nameTemplate, { number: Number(S.startNumber) || 1, pad: S.pad, prompt: 'A red apple on a wooden table', prefix: S.namePrefix }) + ext;
  updateLiveCount();
  renderDir();
}
function saveSettings() { chrome.storage.local.set({ settings: S }); }

function bindSettings() {
  $$('[data-set]').forEach((el) => {
    const handler = () => {
      const k = el.dataset.set;
      S[k] = el.type === 'checkbox' ? el.checked : el.type === 'number' || el.type === 'range' ? Number(el.value) : el.value;
      saveSettings(); refreshDerived();
    };
    el.addEventListener('change', handler);
    if (el.type === 'range' || el.tagName === 'INPUT' && el.type === 'text') el.addEventListener('input', handler);
  });
  $('#namePreset').addEventListener('change', (e) => {
    if (e.target.value !== 'custom') S.nameTemplate = e.target.value;
    $('#tplWrap').classList.toggle('hide', e.target.value !== 'custom');
    saveSettings(); applySettingsToUI();
    if (e.target.value === 'custom') { $('#namePreset').value = 'custom'; $('#tplWrap').classList.remove('hide'); }
  });
  $('#quickUpscale').addEventListener('change', (e) => {
    if (e.target.value === 'off') S.upscale = false; else { S.upscale = true; S.upScale = e.target.value; }
    saveSettings(); applySettingsToUI();
  });
}

function showTab(name) {
  $$('#tabs button').forEach((b) => b.classList.toggle('on', b.dataset.tab === name));
  ['generate', 'settings', 'adobe', 'activity', 'licence'].forEach((t) => $('#v-' + t).classList.toggle('hide', t !== name));
  if (name === 'activity') renderLog();
}

async function runBenchmark() {
  const btn = $('#benchBtn'); btn.disabled = true;
  $('#benchLine').textContent = 'Testing… loading the AI model (the first time can take a minute).';
  try {
    const r = await benchmark(S.upModel, 'auto');
    const gpu = r.backend === 'webgpu';
    const secs = Math.max(1, Math.round(r.estSeconds));
    let verdict;
    if (secs <= 45) verdict = 'Great — this computer handles it well.';
    else if (secs <= 150) verdict = 'OK — usable, a little slow.';
    else verdict = S.upModel === 'best' ? 'Slow — choose the "Fast" model for this computer.' : 'Slow — upscaling will work but takes time on this computer.';
    $('#benchLine').textContent = `${gpu ? 'Graphics card found (WebGPU)' : 'No usable graphics card — using CPU'} · about ${secs >= 90 ? Math.round(secs / 60) + ' min' : secs + ' s'} per image with the "${S.upModel === 'best' ? 'Best quality' : 'Fast'}" model. ${verdict}`;
    log('Upscale test: ' + $('#benchLine').textContent);
  } catch (e) {
    $('#benchLine').textContent = 'This computer could not run the upscaler: ' + e.message;
  }
  btn.disabled = false;
}

const PROJECT_INSTRUCTIONS = `I create stock images for Adobe Stock. Each message I send describes one image. Create one new image for it straight away, without asking questions.

Make every image:
- sharp, clean and well lit, with balanced exposure and natural colours
- anatomically accurate, with natural faces, hands and proportions
- one clear idea with a strong main subject and a little empty space for copy
- plain: no text, lettering, watermark, logo or border in the picture
- generic: people and products are fictional and unbranded
- clearly different from the earlier images in subject, setting, viewpoint and lighting

For vector or icon requests use flat solid shapes, clean outlines and a few flat colours on a plain white background.
Reply with the image only.`;

// ───────────────────────── boot ─────────────────────────
async function init() {
  fillSelect($('#sepSelect'), SEPARATORS);
  fillSelect($('#modeSel'), MODES);
  fillSelect($('#aspectSel'), ASPECTS);

  const st = await chrome.storage.local.get(['settings', 'queue', 'logs', 'userName', 'userPhone', 'profile', 'madeTotal']);
  madeTotal = st.madeTotal || 0;
  $('#uState').innerHTML = '<option value="">Choose…</option>' + STATES.map((x) => `<option>${x}</option>`).join('');
  const pf = st.profile || {};
  $('#uEmail').value = pf.email || ''; $('#uState').value = pf.state || ''; $('#uRef').value = pf.refCode || '';
  S = Object.assign({}, DEFAULTS, st.settings || {});
  queue = (st.queue || []).map((i) => Object.assign(i, { status: ['done', 'failed'].includes(i.status) ? i.status : 'pending' }));
  logs = st.logs || [];
  $('#uName').value = st.userName || ''; $('#uPhone').value = st.userPhone || '';
  try { dirHandle = (await idbGet('dir')) || null; } catch { dirHandle = null; }

  bindSettings(); applySettingsToUI(); renderQueue();

  $$('#tabs button').forEach((b) => b.addEventListener('click', () => showTab(b.dataset.tab)));
  $('#licChip').addEventListener('click', () => showTab('licence'));
  $('#promptBox').addEventListener('input', updateLiveCount);
  $('#loadBtn').addEventListener('click', loadPrompts);
  $('#loadFile').addEventListener('click', () => $('#fileInput').click());
  $('#fileInput').addEventListener('change', async (e) => {
    const f = e.target.files[0]; if (!f) return;
    const text = await f.text();
    $('#promptBox').value = ($('#promptBox').value ? $('#promptBox').value + '\n' : '') + text;
    e.target.value = ''; updateLiveCount();
    toast('File opened — check the count, then press "Load prompts into queue"');
  });
  $('#startBtn').addEventListener('click', start);
  $('#pauseBtn').addEventListener('click', togglePause);
  $('#stopBtn').addEventListener('click', stop);
  $('#retryFailed').addEventListener('click', () => {
    const n = queue.filter((i) => i.status === 'failed').length;
    if (!n) { toast('No failed prompts'); return; }
    queue.forEach((i) => { if (i.status === 'failed') { i.status = 'pending'; i.error = ''; } });
    renderQueue(); persistSoon(); toast(n + ' prompts ready to retry — press Start');
  });
  $('#clearDone').addEventListener('click', () => { queue = queue.filter((i) => i.status !== 'done'); renderQueue(); persistSoon(); });
  $('#clearQueue').addEventListener('click', () => {
    if (run.active) { toast('Stop the run first'); return; }
    queue = []; sessionHashes.length = 0; $('#dupWarn').classList.add('hide'); renderQueue(); persistSoon();
  });
  $('#clearLog').addEventListener('click', () => { logs = []; renderLog(); persistSoon(); });
  $('#resetSettings').addEventListener('click', () => { S = Object.assign({}, DEFAULTS); saveSettings(); applySettingsToUI(); toast('Settings reset'); });
  $('#benchBtn').addEventListener('click', runBenchmark);
  $('#pickDir').addEventListener('click', async () => {
    try {
      dirHandle = await window.showDirectoryPicker({ mode: 'readwrite' });
      await idbSet('dir', dirHandle); renderDir();
    } catch { /* cancelled */ }
  });
  $('#clearDir').addEventListener('click', async () => { dirHandle = null; await idbSet('dir', null); renderDir(); });
  $('#copyInstr').addEventListener('click', async () => { await navigator.clipboard.writeText(PROJECT_INSTRUCTIONS); toast('Instructions copied'); });
  $('#primeBtn').addEventListener('click', async () => {
    if (run.active) { toast('Stop the run first'); return; }
    try {
      await findTab(true); await waitReady(30000);
      const r = await cs('send', { text: PRIME_MESSAGE });
      toast(r && r.ok ? 'Rules sent to ChatGPT' : (r && r.error) || 'Could not send');
    } catch (e) { toast(e.message); }
  });
  $('#copyId').addEventListener('click', async () => { await navigator.clipboard.writeText(device.deviceId); toast('Device ID copied'); });
  $('#recheck').addEventListener('click', async () => { await refreshLicence(true); toast(licence.active ? 'Licence is active' : STATE_TEXT[licence.state] || 'Not active'); });
  $('#packs').addEventListener('click', (e) => { const b = e.target.closest('[data-pack]'); if (b) { chosenPack = b.dataset.pack; renderPacks(); } });
  $('#sendReq').addEventListener('click', sendRequest);
  $('#payOnlineBtn').addEventListener('click', openPay);
  const upNow = () => { const up = srvConfig && srvConfig.update; if (up && up.url) showUpdatePopup(up, chrome.runtime.getManifest().version, true); };
  $('#updateNow').addEventListener('click', upNow);
  $('#gateUpdNow').addEventListener('click', upNow);
  $('#connectBtn').addEventListener('click', connectAccount);
  $('#gateConnect').addEventListener('click', connectAccount);
  $('#gateMove').addEventListener('click', async () => {
    const left = me && me.account ? me.account.movesLeft : 0;
    if (!confirm('এই কম্পিউটারে লাইসেন্স চালু করবেন? পুরোনো কম্পিউটারে বন্ধ হয়ে যাবে। এ মাসে আর ' + left + ' বার বদলানো যাবে।')) return;
    try { licence = await moveHere(); me = licence.me || me; renderLicence(); renderAccount(); toast(licence.active ? '✅ এই কম্পিউটারে চালু হয়েছে' : (licence.message || 'হয়নি')); }
    catch (e) { toast(e.message || 'হয়নি'); }
  });
  $('#payBox').addEventListener('click', (e) => { const b = e.target.closest('[data-qr]'); if (b) { chosenQr = b.dataset.qr; renderPacks(); } });
  $('#themeSw').addEventListener('click', (e) => { const b = e.target.closest('[data-theme]'); if (b) { S.theme = b.dataset.theme; saveSettings(); applyTheme(); } });
  $('#copyRef').addEventListener('click', async () => { await navigator.clipboard.writeText($('#refCode').textContent); toast('Referral code copied'); });
  $('#ideaBtn').addEventListener('click', () => makePrompts(false));
  $('#ideaImport').addEventListener('click', () => makePrompts(true));
  $('#queue').addEventListener('click', (e) => {
    const row = e.target.closest('.qi'); if (!row) return;
    const it = queue.find((q) => q.id === row.dataset.id);
    if (it && (it.report || it.preview)) guide.openPreview(it);
  });
  $('#howBtn').addEventListener('click', () => guide.openHowTo(srvConfig, runTour, playerUrl));
  $('#announce').addEventListener('click', () => guide.maybeShowOffer(srvConfig, acceptOffer, true));

  device = await getDevice();
  $('#devId').textContent = device.deviceId;
  await refreshLicence();
  if (licence.active && !(await chrome.storage.local.get('tourDone')).tourDone) runTour();
  setInterval(renderLicence, 1000);
  setInterval(refreshLicence, CONFIG.CHECK_INTERVAL_MS);
  window.addEventListener('beforeunload', (e) => { if (run.active) { e.preventDefault(); e.returnValue = ''; } });
}

init();
