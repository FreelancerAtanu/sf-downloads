// ─────────────────────────────────────────────────────────────
//  Skillful Freelance — Bulk Image Generator : build configuration
//
//  SERVER_URL  : address of your Skillful Freelance platform (the Super Admin server).
//                On your own PC for testing: http://localhost:8787
//                After uploading to Hostinger: https://your-domain (no "/" at the end)
//  PRODUCT_ID  : which extension this is inside the Super Admin panel. Do not change.
//  PUBLIC_KEY  : must match Super Admin → an extension → Control → "Connect this extension".
// ─────────────────────────────────────────────────────────────
export const CONFIG = {
  SERVER_URL: 'https://admin.skillfulfreelance.com',
  PRODUCT_ID: 'bulk-image',
  PUBLIC_KEY: {"kty":"EC","crv":"P-256","x":"jCfBBwvj84X8ALCBdHH6u6ljuYkuHNQAxBFGXvdxxLo","y":"QW1q4LLd4o_B-axORTg_xVP5c_bBM0dWmaTb9_byG_k"},
  BRAND: 'Skillful Freelance',
  PRODUCT: 'Bulk Image Generator',
  DEVELOPER: 'Atanu Sarkar',
  WHATSAPP: '917719132922',       // fallback until the server sends its own value
  CHECK_INTERVAL_MS: 60000
};
